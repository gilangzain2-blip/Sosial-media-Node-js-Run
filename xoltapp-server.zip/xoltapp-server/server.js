'use strict';
// XoltApp server: API + penyimpanan + file statis. Tanpa dependensi (tidak perlu npm install). Node 18+.
const fs=require('fs'),path=require('path'),http=require('http'),crypto=require('crypto');
try{fs.readFileSync(path.join(__dirname,'.env'),'utf8').split(/\r?\n/).forEach(l=>{const m=l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);if(m&&!(m[1] in process.env))process.env[m[1]]=m[2].replace(/^(["'])(.*)\1$/,'$2')})}catch(e){}
const PORT=+process.env.SERVER_PORT||+process.env.PORT||3000;
const DATA=process.env.DATA_DIR||path.join(__dirname,'data'),UP=path.join(DATA,'uploads'),PUB=path.join(__dirname,'public'),DBF=path.join(DATA,'db.json');
fs.mkdirSync(UP,{recursive:true});
let db={v:1,users:{},tokens:{},posts:[],stories:[],chats:{global:[]},rooms:[]};
try{Object.assign(db,JSON.parse(fs.readFileSync(DBF,'utf8')))}catch(e){}
const norm=u=>{u.sv=u.sv||[];u.blk=u.blk||[];u.rd=u.rd||{};u.nf=u.nf||[];u.nr=u.nr||0;u.fb=u.fb||0;u.lb=u.lb||0;u.items=u.items||[];u.fr=u.fr||'';u.dly=u.dly||{d:0,s:0};u.fol=u.fol||[];return u};
for(const k in db.users)norm(db.users[k]);db.reports=db.reports||[];db.gl=db.gl||[];
let tm=null;
function flush(){try{fs.writeFileSync(DBF+'.tmp',JSON.stringify(db));fs.renameSync(DBF+'.tmp',DBF)}catch(e){console.error('simpan gagal:',e.message)}}
function save(){db.v++;clearTimeout(tm);tm=setTimeout(flush,250)}
process.on('SIGTERM',()=>{flush();process.exit(0)});process.on('SIGINT',()=>{flush();process.exit(0)});
const hashPw=(u,p)=>{u.salt=crypto.randomBytes(16).toString('hex');u.hash=crypto.scryptSync(p,u.salt,32).toString('hex')};
const checkPw=(u,p)=>{if(!u.hash)return false;const h=crypto.scryptSync(p,u.salt,32),k=Buffer.from(u.hash,'hex');return h.length===k.length&&crypto.timingSafeEqual(h,k)};
// Owner dari environment (tidak ada di kode)
const OU=(process.env.OWNER_USERNAME||'').trim(),OL=OU.toLowerCase(),OP=process.env.OWNER_PASSWORD||'';
if(OL&&OP){let o=db.users[OL];if(!o)o=db.users[OL]={u:OL,n:OU,bio:'Owner XoltApp',av:'👑',coins:100,fol:[],t:Date.now()};if(!checkPw(o,OP))hashPw(o,OP);norm(o);o.owner=true;o.v=1}
else console.warn('PERINGATAN: OWNER_USERNAME / OWNER_PASSWORD belum diisi, panel owner nonaktif.');
for(const k in db.users)if(k!==OL)db.users[k].owner=false;
let off=db.rooms.find(r=>r.off);if(!off){off={id:'r:resmi',n:'XoltApp Resmi',t:'c',m:[],ad:[],off:1};db.rooms.unshift(off)}off.o=OL;
db.chats.global=db.chats.global||[];save();
const hits=new Map();
const limited=ip=>{const n=Date.now(),a=(hits.get(ip)||[]).filter(t=>n-t<6e4);a.push(n);hits.set(ip,a);return a.length>20};
const CORS={'Access-Control-Allow-Origin':process.env.ALLOW_ORIGIN||'*','Access-Control-Allow-Headers':'Authorization,Content-Type','Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS'};
const json=(res,code,o)=>{res.writeHead(code,{...CORS,'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(o))};
const fail=(c,m)=>{throw Object.assign(new Error(m),{code:c})};
const readBody=(req,max)=>new Promise((ok,no)=>{let n=0;const c=[];req.on('data',d=>{n+=d.length;if(n>max){no(Object.assign(new Error('Data terlalu besar'),{code:413}));req.destroy()}else c.push(d)});req.on('end',()=>{try{ok(c.length?JSON.parse(Buffer.concat(c).toString()):{})}catch(e){no(Object.assign(new Error('JSON tidak valid'),{code:400}))}});req.on('error',no)});
const pub=u=>({u:u.u,n:u.n,bio:u.bio||'',av:u.av||'🙂',pic:u.pic||'',v:u.v?1:0,owner:u.owner?1:0});
const self=u=>({...pub(u),coins:u.coins,fol:u.fol||[]});
const pk=(a,b)=>[a,b].sort().join('|');
const isAdm=(r,u)=>r.o===u||(r.ad||[]).includes(u);
const mediaOk=s=>typeof s==='string'&&/^\/uploads\/[a-f0-9]{16,}\.[a-z0-9]{2,4}$/.test(s);
const str=(s,n)=>String(s==null?'':s).slice(0,n);
const typ={},today=()=>Math.floor((Date.now()+7*36e5)/864e5);
const SHOP=[{id:'fr-emas',n:'Bingkai Emas',c:500},{id:'fr-petir',n:'Bingkai Petir',c:800},{id:'fr-api',n:'Bingkai Api',c:1200}];
const REACT=['👍','❤️','😂','😮','😢','🙏'];
const isPub=r=>r.off||(r.pub===undefined?r.t==='c':!!r.pub);
const mutual=(a,b)=>!!(a&&b&&a.sv.includes(b.u)&&b.sv.includes(a.u));
let mid=Date.now();
function notify(to,type,from,text,pid){const t=db.users[to];if(!t||to===from)return;t.nf.push({id:++mid,type,from,text:str(text,80),pid:pid||0,ts:Date.now()});if(t.nf.length>60)t.nf.splice(0,t.nf.length-60)}
function mentions(t,from,where,pid){const s=new Set();(String(t).match(/@([a-z0-9_]{3,20})/g)||[]).forEach(x=>{const n=x.slice(1);if(db.users[n]&&n!==from&&!s.has(n)){s.add(n);notify(n,'mention',from,where+': '+t,pid)}})}
function resolveKey(u,k,write){k=str(k,60);
  if(k==='global')return{key:'global'};
  if(k.startsWith('r:')){const r=db.rooms.find(x=>x.id===k);if(!r)fail(404,'Grup tidak ditemukan');
    if(write){if(r.off){if(r.o!==u.u)fail(403,'Hanya owner yang bisa mengirim di channel resmi')}else if(r.t==='c'){if(!isAdm(r,u.u))fail(403,'Hanya admin channel yang bisa mengirim')}else if(!r.m.includes(u.u))fail(403,'Kamu bukan anggota grup ini')}
    else if(!(r.off||r.m.includes(u.u)||r.o===u.u))fail(403,'Tidak diizinkan');
    return{key:r.id,room:r}}
  if(k.includes('|')&&k.split('|').includes(u.u)&&k.split('|').every(x=>db.users[x]))return{key:k};
  const t=db.users[k];if(!t||t===u)fail(404,'Pengguna tidak ditemukan');return{key:pk(u.u,k),other:t}}
const GIFTS=[['🌹','Mawar',10],['☕','Kopi',20],['❤️','Hati',50],['👑','Mahkota',200],['🚀','Roket',500],['💎','Berlian',1000]];
const EXT={'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov','audio/webm':'weba','audio/ogg':'ogg','audio/mp4':'m4a','audio/x-m4a':'m4a','audio/mpeg':'mp3','audio/wav':'wav'};
function addMsg(key,m){m.id=++mid;m.ts=Date.now();const l=(db.chats[key]=db.chats[key]||[]);l.push(m);if(l.length>600)l.splice(0,l.length-600)}
function live(u){const pr={};for(const k in db.users)pr[k]=db.users[k].ls||0;const ty={},n=Date.now();
  for(const k in typ){const names=Object.keys(typ[k]).filter(x=>x!==u.u&&n-typ[k][x]<5000);if(!names.length)continue;
    if(k==='global'||(k.startsWith('r:')&&db.rooms.some(r=>r.id===k&&(r.off||r.m.includes(u.u))))||(k.includes('|')&&k.split('|').includes(u.u)))ty[k]=names}
  return{now:n,pr,ty}}
function state(u){const now=Date.now(),keep=db.stories.filter(s=>now-s.t<864e5);if(keep.length!==db.stories.length)db.stories=keep;
  const fc={},lc={};for(const k in db.users)for(const f of db.users[k].fol)fc[f]=(fc[f]||0)+1;for(const p of db.posts)lc[p.u]=(lc[p.u]||0)+p.by.length;
  const users={};for(const k in db.users){const x=db.users[k];users[k]={...pub(x),fl:Math.max(0,(fc[k]||0)+x.fb),fg:x.fol.length,lk:Math.max(0,(lc[k]||0)+x.lb),fol:x.fol,fr:x.fr,fd:mutual(u,x)?1:0,sd:u.sv.includes(k)?1:0,bk:u.blk.includes(k)?1:0,bn:x.ban?1:0};if(u.owner){users[k].fb=x.fb;users[k].lb=x.lb;users[k].rf=fc[k]||0;users[k].rl=lc[k]||0}}
  Object.assign(users[u.u],{coins:u.coins,rd:u.rd,nf:u.nf.slice(-40),nr:u.nr,blk:u.blk,sv:u.sv,items:u.items,dly:{can:u.dly.d!==today(),s:u.dly.s}});
  const rooms=db.rooms.filter(r=>isPub(r)||r.m.includes(u.u)),chats={global:(db.chats.global||[]).filter(m=>!u.blk.includes(m.f)).slice(-150)},reads={};
  for(const r of rooms)if(r.off||r.m.includes(u.u)||r.o===u.u)chats[r.id]=(db.chats[r.id]||[]).slice(-150);
  for(const k in db.chats)if(k.includes('|')){const ps=k.split('|');if(ps.includes(u.u)){chats[k]=db.chats[k].slice(-150);const o=db.users[ps[0]===u.u?ps[1]:ps[0]];if(o)reads[k]=o.rd[k]||0}}
  return{v:db.v,me:u.u,users,posts:db.posts.filter(p=>!u.blk.includes(p.u)).slice(0,100),
    stories:db.stories.filter(s=>!u.blk.includes(s.u)&&(s.vis!=='priv'||s.u===u.u||mutual(u,db.users[s.u]))),rooms,chats,reads,shop:SHOP,reports:u.owner?db.reports.filter(x=>!x.done).slice(-30).reverse():[],...live(u)}}
function delUser(n){delete db.users[n];for(const k in db.tokens)if(db.tokens[k]===n)delete db.tokens[k];
  db.posts=db.posts.filter(p=>p.u!==n);db.stories=db.stories.filter(s=>s.u!==n);db.rooms=db.rooms.filter(r=>r.off||r.o!==n);
  for(const r of db.rooms){r.m=r.m.filter(x=>x!==n);r.ad=(r.ad||[]).filter(x=>x!==n);if(r.bl)r.bl=r.bl.filter(x=>x!==n)}
  for(const k of Object.keys(db.chats)){if(k.includes('|')&&k.split('|').includes(n))delete db.chats[k];else if(k.startsWith('r:')&&!db.rooms.some(r=>r.id===k))delete db.chats[k]}
  for(const k in db.users){const x=db.users[k];x.fol=x.fol.filter(y=>y!==n);x.sv=x.sv.filter(y=>y!==n);x.blk=x.blk.filter(y=>y!==n)}
  for(const p of db.posts){p.by=p.by.filter(x=>x!==n);p.c=p.c.filter(c=>c.u!==n)}}
async function handleApi(req,res,url){
  const m=req.method,p=url.pathname;let u=null,mm;
  const tk=(req.headers.authorization||'').replace(/^Bearer /,'');if(tk&&db.tokens[tk])u=db.users[db.tokens[tk]];
  if(m==='POST'&&(p==='/api/register'||p==='/api/login')){
    if(limited(req.socket.remoteAddress))fail(429,'Terlalu banyak percobaan, tunggu sebentar');
    const b=await readBody(req,5e3),name=str(b.u,20).toLowerCase(),pw=str(b.p,100);
    if(!/^[a-z0-9_]{3,20}$/.test(name))fail(400,'Username 3-20 karakter: huruf kecil, angka, _');
    if(pw.length<6)fail(400,'Sandi minimal 6 karakter');
    let x=db.users[name];
    if(p==='/api/register'){if(name===OL)fail(409,'Username itu dicadangkan untuk owner');if(x)fail(409,'Username sudah dipakai');
      const AV=['😎','🙂','🤩','😺','🦊','🐼'];x=db.users[name]={u:name,n:str(b.n,30).trim()||name,bio:'Baru bergabung di XoltApp',av:AV[Object.keys(db.users).length%6],coins:100,fol:[],t:Date.now()};norm(x);const gl=db.chats.global;if(gl&&gl.length)x.rd.global=gl[gl.length-1].id;hashPw(x,pw)}
    else if(!x||!checkPw(x,pw))fail(401,'Username atau sandi salah');
    if(x.ban)fail(403,'Akun dibekukan oleh owner');
    const t=crypto.randomBytes(24).toString('hex');db.tokens[t]=name;save();return json(res,200,{token:t})}
  if(!u)fail(401,'Belum masuk');if(u.ban)fail(403,'Akun dibekukan oleh owner');u.ls=Date.now();
  if(m==='GET'&&p==='/api/state'){if(+url.searchParams.get('v')===db.v)return json(res,200,{same:1,...live(u)});return json(res,200,state(u))}
  if(m==='POST'&&p==='/api/logout'){delete db.tokens[tk];save();return json(res,200,{ok:1})}
  if(m==='PUT'&&p==='/api/me'){const b=await readBody(req,5e3);
    if(b.n!==undefined){const n=str(b.n,30).trim();if(!n)fail(400,'Nama tidak boleh kosong');u.n=n}
    if(b.bio!==undefined)u.bio=str(b.bio,120);
    if(b.pic!==undefined){if(b.pic===null)u.pic='';else if(mediaOk(b.pic))u.pic=b.pic;else fail(400,'Foto tidak valid')}
    save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/follow'){const b=await readBody(req,1e3),t=db.users[str(b.u,20)];if(!t||t===u)fail(400,'Pengguna tidak ditemukan');const i=u.fol.indexOf(t.u);if(i<0){u.fol.push(t.u);notify(t.u,'follow',u.u,'mulai mengikutimu')}else u.fol.splice(i,1);save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/upload'){const b=await readBody(req,40e6),d=b.data;if(typeof d!=='string')fail(400,'File kosong');
    const h=/^data:([a-z0-9]+\/[a-z0-9.+-]+)(?:;[^,]*)?;base64,/i.exec(d.slice(0,120));if(!h)fail(400,'Format file tidak valid');
    const ext=EXT[h[1].toLowerCase()];if(!ext)fail(415,'Jenis file tidak didukung');
    const buf=Buffer.from(d.slice(h[0].length),'base64');if(!buf.length||buf.length>25e6)fail(413,'Ukuran file maksimal 25 MB');
    const name=crypto.randomBytes(12).toString('hex')+'.'+ext;fs.writeFileSync(path.join(UP,name),buf);return json(res,200,{url:'/uploads/'+name})}
  if(m==='POST'&&p==='/api/posts'){const b=await readBody(req,6e3),t=str(b.t,1000).trim(),imgs=(Array.isArray(b.imgs)?b.imgs:[]).slice(0,4),vid=b.vid||'';let poll=null;
    if(b.poll&&Array.isArray(b.poll.o)){const o=b.poll.o.map(x=>str(x,40).trim()).filter(Boolean).slice(0,4);if(o.length<2)fail(400,'Polling butuh minimal 2 pilihan');poll={o:o.map(x=>({t:x,v:[]}))}}
    if(!t&&!imgs.length&&!vid&&!poll)fail(400,'Postingan kosong');if(imgs.some(x=>!mediaOk(x))||(vid&&!mediaOk(vid)))fail(400,'Media tidak valid');
    const po={id:++mid,u:u.u,t,img:imgs[0]||'',imgs,vid,ts:Date.now(),by:[],c:[],rx:{},gf:0,gc:0};if(poll)po.poll=poll;
    db.posts.unshift(po);if(db.posts.length>300)db.posts.length=300;mentions(t,u.u,'postingan',po.id);save();return json(res,200,{ok:1})}
  if(m==='DELETE'&&(mm=/^\/api\/posts\/(\d+)$/.exec(p))){const i=db.posts.findIndex(x=>x.id==mm[1]);if(i<0)fail(404,'Tidak ditemukan');if(db.posts[i].u!==u.u&&!u.owner)fail(403,'Bukan postinganmu');db.posts.splice(i,1);save();return json(res,200,{ok:1})}
  if(m==='POST'&&(mm=/^\/api\/posts\/(\d+)\/(like|comments|react|vote)$/.exec(p))){const po=db.posts.find(x=>x.id==mm[1]);if(!po)fail(404,'Tidak ditemukan');
    if(mm[2]==='like'){const i=po.by.indexOf(u.u);if(i<0){po.by.push(u.u);notify(po.u,'like',u.u,'menyukai postinganmu',po.id)}else po.by.splice(i,1)}
    else if(mm[2]==='react'){const b=await readBody(req,1e3);if(!REACT.includes(b.e))fail(400,'Reaksi tidak valid');po.rx=po.rx||{};const l=(po.rx[b.e]=po.rx[b.e]||[]),i=l.indexOf(u.u);i<0?l.push(u.u):l.splice(i,1);if(!l.length)delete po.rx[b.e]}
    else if(mm[2]==='vote'){const b=await readBody(req,1e3),i=+b.i;if(!po.poll||!(i>=0&&i<po.poll.o.length))fail(400,'Pilihan tidak valid');po.poll.o.forEach(o=>{o.v=o.v.filter(x=>x!==u.u)});po.poll.o[i].v.push(u.u)}
    else{const b=await readBody(req,2e3),t=str(b.t,300).trim();if(!t)fail(400,'Komentar kosong');po.c.push({u:u.u,t});notify(po.u,'comment',u.u,t,po.id);mentions(t,u.u,'komentar',po.id)}
    save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/stories'){const b=await readBody(req,5e3),txt=str(b.txt,150).trim(),img=b.img||'',vid=b.vid||'';
    if(!txt&&!img&&!vid)fail(400,'Cerita kosong');if((img&&!mediaOk(img))||(vid&&!mediaOk(vid)))fail(400,'Media tidak valid');
    db.stories.unshift({id:String(++mid),u:u.u,txt,img,vid,t:Date.now(),seen:[u.u],vis:b.vis==='priv'?'priv':'pub',gf:0,gc:0});save();return json(res,200,{ok:1})}
  if((mm=/^\/api\/stories\/(\d+)(\/seen)?$/.exec(p))){const s=db.stories.find(x=>x.id===mm[1]);if(!s)fail(404,'Tidak ditemukan');
    if(m==='DELETE'){if(s.u!==u.u&&!u.owner)fail(403,'Bukan ceritamu');db.stories=db.stories.filter(x=>x!==s);save();return json(res,200,{ok:1})}
    if(m==='POST'&&mm[2]){if(!s.seen.includes(u.u)){s.seen.push(u.u);save()}return json(res,200,{ok:1})}}
  if(m==='POST'&&p==='/api/chat'){const b=await readBody(req,5e3),t=str(b.t,500).trim();let vn=null;
    if(b.vn){if(!mediaOk(b.vn.url)||!(+b.vn.d>0))fail(400,'Voice note tidak valid');vn={url:b.vn.url,d:Math.min(600,Math.round(+b.vn.d))}}
    if(!t&&!vn)fail(400,'Pesan kosong');
    const{key,other}=resolveKey(u,b.to,true);
    if(other&&(other.blk.includes(u.u)||u.blk.includes(other.u)))fail(403,'Tidak bisa mengirim pesan ke pengguna ini');
    const msg={f:u.u};if(t)msg.t=t;if(vn)msg.vn=vn;
    const rm=b.re&&(db.chats[key]||[]).find(x=>x.id===+b.re);if(rm)msg.re={id:rm.id,f:rm.f,t:rm.del?'Pesan dihapus':str(rm.t||(rm.vn?'🎤 Voice note':rm.g?'🎁 Hadiah':''),60)};
    addMsg(key,msg);if(t&&!other)mentions(t,u.u,key==='global'?'Global':'Grup');save();return json(res,200,{ok:1})}
  if(m==='PUT'&&p==='/api/msg'){const b=await readBody(req,2e3),{key}=resolveKey(u,b.k),mg=(db.chats[key]||[]).find(x=>x.id===+b.id),t=str(b.t,500).trim();
    if(!mg||mg.f!==u.u||mg.del||!mg.t)fail(403,'Tidak bisa mengedit pesan ini');if(!t)fail(400,'Pesan kosong');mg.t=t;mg.ed=1;save();return json(res,200,{ok:1})}
  if(m==='DELETE'&&p==='/api/msg'){const b=await readBody(req,2e3),{key,room}=resolveKey(u,b.k),mg=(db.chats[key]||[]).find(x=>x.id===+b.id);
    if(!mg)fail(404,'Pesan tidak ditemukan');if(mg.f!==u.u&&!u.owner&&!(room&&isAdm(room,u.u)))fail(403,'Tidak boleh menghapus pesan ini');
    mg.del=1;delete mg.t;delete mg.vn;delete mg.g;delete mg.re;delete mg.rx;save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/react'){const b=await readBody(req,2e3),{key}=resolveKey(u,b.k),mg=(db.chats[key]||[]).find(x=>x.id===+b.id);
    if(!mg||mg.del)fail(404,'Pesan tidak ditemukan');if(!REACT.includes(b.e))fail(400,'Reaksi tidak valid');
    mg.rx=mg.rx||{};const l=(mg.rx[b.e]=mg.rx[b.e]||[]),i=l.indexOf(u.u);i<0?l.push(u.u):l.splice(i,1);if(!l.length)delete mg.rx[b.e];save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/gift'){const b=await readBody(req,1e3),g=GIFTS[+b.i];let to,tgt=null;
    if(!g)fail(400,'Hadiah tidak valid');
    if(b.post){tgt=db.posts.find(x=>x.id==b.post);if(!tgt)fail(404,'Postingan tidak ditemukan');to=db.users[tgt.u]}
    else if(b.story){tgt=db.stories.find(x=>x.id===String(b.story));if(!tgt)fail(404,'Cerita tidak ditemukan');to=db.users[tgt.u]}
    else to=db.users[str(b.to,20)];
    if(!to||to===u)fail(404,'Penerima tidak valid');if(u.coins<g[2])fail(400,'Koin tidak cukup');
    u.coins-=g[2];to.coins+=g[2];db.gl.push({f:u.u,t:to.u,c:g[2],ts:Date.now()});if(db.gl.length>3000)db.gl.splice(0,500);
    if(tgt){tgt.gf=(tgt.gf||0)+1;tgt.gc=(tgt.gc||0)+g[2]}else addMsg(pk(u.u,to.u),{f:u.u,g});
    notify(to.u,'gift',u.u,g[0]+' '+g[1]+' ('+g[2]+' koin)',b.post||0);save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/rooms'){const b=await readBody(req,3e3),n=str(b.n,30).trim(),t=b.t==='c'?'c':'g';if(!n)fail(400,'Nama wajib diisi');
    let mem=[u.u];if(t==='g'){const l=[...new Set((Array.isArray(b.m)?b.m:[]).map(x=>str(x,20)).filter(x=>db.users[x]&&x!==u.u))];if(!l.length&&!b.pub)fail(400,'Pilih minimal 1 anggota');mem=[...l,u.u]}
    const r={id:'r:'+(++mid),n,t,o:u.u,ad:[],m:mem,pub:b.pub?1:0};db.rooms.push(r);mem.forEach(x=>notify(x,'room',u.u,'menambahkanmu ke '+n));save();return json(res,200,{id:r.id})}
  if((mm=/^\/api\/rooms\/(r:[a-z0-9]+)\/(join|op)$/.exec(p))&&m==='POST'){const r=db.rooms.find(x=>x.id===mm[1]);if(!r)fail(404,'Tidak ditemukan');
    if(mm[2]==='join'){if(!isPub(r)||r.off)fail(400,'Tidak bisa bergabung');if((r.bl||[]).includes(u.u))fail(403,'Kamu dikeluarkan dari channel ini');if(!r.m.includes(u.u))r.m.push(u.u);save();return json(res,200,{ok:1})}
    const b=await readBody(req,3e3),tg=str(b.u,20),adm=isAdm(r,u.u),cr=r.o===u.u;r.ad=r.ad||[];
    switch(b.op){
      case 'name':{if(!adm)fail(403,'Hanya admin');const n=str(b.n,30).trim();if(!n)fail(400,'Nama tidak boleh kosong');r.n=n;break}
      case 'pic':if(!adm)fail(403,'Hanya admin');if(b.pic===null)delete r.pic;else if(mediaOk(b.pic))r.pic=b.pic;else fail(400,'Foto tidak valid');break;
      case 'adm':if(!adm||r.off)fail(403,'Hanya admin');if(r.m.includes(tg)&&!r.ad.includes(tg)&&tg!==r.o)r.ad.push(tg);break;
      case 'copot':if(!cr)fail(403,'Hanya pembuat');r.ad=r.ad.filter(x=>x!==tg);break;
      case 'kick':if(!adm||r.off)fail(403,'Hanya admin');if(tg===r.o||tg===u.u)fail(400,'Tidak bisa mengeluarkan akun ini');if(r.ad.includes(tg)&&!cr)fail(403,'Hanya pembuat yang bisa mengeluarkan admin');
        r.m=r.m.filter(x=>x!==tg);r.ad=r.ad.filter(x=>x!==tg);if(isPub(r))(r.bl=r.bl||[]).push(tg);break;
      case 'vis':if(!adm||r.off)fail(403,'Hanya admin');r.pub=isPub(r)?0:1;break;
      case 'add':if(!adm||r.off)fail(403,'Hanya admin');if(db.users[tg]&&!r.m.includes(tg)){r.m.push(tg);r.bl=(r.bl||[]).filter(x=>x!==tg);notify(tg,'room',u.u,'menambahkanmu ke '+r.n)}break;
      case 'leave':if(cr||r.off)fail(400,'Pembuat tidak bisa keluar');r.m=r.m.filter(x=>x!==u.u);r.ad=r.ad.filter(x=>x!==u.u);break;
      default:fail(400,'Aksi tidak dikenal')}
    save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/owner/verify'){if(!u.owner)fail(403,'Khusus owner');const b=await readBody(req,1e3),t=db.users[str(b.u,20)];if(!t||t.owner)fail(400,'Tidak valid');t.v=t.v?0:1;save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/owner/announce'){if(!u.owner)fail(403,'Khusus owner');const b=await readBody(req,2e3),t=str(b.t,300).trim();if(!t)fail(400,'Pengumuman kosong');
    addMsg('r:resmi',{f:u.u,t:'📢 '+t});addMsg('global',{f:u.u,t:'📢 '+t});save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/read'){const b=await readBody(req,1e3),{key}=resolveKey(u,b.k),l=db.chats[key]||[],last=l.length?l[l.length-1].id:0;if((u.rd[key]||0)<last){u.rd[key]=last;save()}return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/typing'){const b=await readBody(req,1e3),{key}=resolveKey(u,b.k,true);(typ[key]=typ[key]||{})[u.u]=Date.now();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/nread'){u.nr=Date.now();save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/save'){const b=await readBody(req,1e3),t=db.users[str(b.u,20)];if(!t||t===u)fail(400,'Pengguna tidak ditemukan');const i=u.sv.indexOf(t.u);if(i<0){u.sv.push(t.u);notify(t.u,'save',u.u,'menyimpan kontakmu')}else u.sv.splice(i,1);save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/block'){const b=await readBody(req,1e3),t=db.users[str(b.u,20)];if(!t||t===u||t.owner)fail(400,'Tidak bisa memblokir akun ini');const i=u.blk.indexOf(t.u);i<0?u.blk.push(t.u):u.blk.splice(i,1);save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/report'){const b=await readBody(req,2e3),t=db.users[str(b.u,20)];if(!t||t===u)fail(400,'Pengguna tidak ditemukan');
    db.reports.push({id:++mid,by:u.u,u:t.u,post:+b.post||0,reason:str(b.reason,200).trim()||'-',ts:Date.now(),done:0});if(db.reports.length>500)db.reports.splice(0,100);
    for(const k in db.users)if(db.users[k].owner)notify(k,'report',u.u,'melaporkan @'+t.u);save();return json(res,200,{ok:1})}
  if(m==='PUT'&&p==='/api/password'){const b=await readBody(req,1e3),np=str(b.n,100);if(!checkPw(u,str(b.o,100)))fail(403,'Sandi lama salah');if(np.length<6)fail(400,'Sandi baru minimal 6 karakter');
    hashPw(u,np);for(const k in db.tokens)if(db.tokens[k]===u.u&&k!==tk)delete db.tokens[k];save();return json(res,200,{ok:1})}
  if(m==='DELETE'&&p==='/api/me'){const b=await readBody(req,1e3);if(u.owner)fail(400,'Akun owner tidak bisa dihapus');if(!checkPw(u,str(b.p,100)))fail(403,'Sandi salah');delUser(u.u);save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/daily'){if(u.dly.d===today())fail(400,'Bonus hari ini sudah diklaim');const s=u.dly.d===today()-1?u.dly.s+1:1,bonus=50+Math.min(s-1,6)*10;u.dly={d:today(),s};u.coins+=bonus;save();return json(res,200,{bonus,streak:s})}
  if(m==='POST'&&p==='/api/shop'){const b=await readBody(req,1e3),it=SHOP.find(x=>x.id===b.id);if(!it)fail(404,'Barang tidak ada');
    if(b.op==='buy'){if(u.items.includes(it.id))fail(400,'Sudah dimiliki');if(u.coins<it.c)fail(400,'Koin tidak cukup');u.coins-=it.c;u.items.push(it.id);u.fr=it.id}
    else if(b.op==='equip'){if(!u.items.includes(it.id))fail(403,'Belum dimiliki');u.fr=it.id}else if(b.op==='unequip')u.fr='';else fail(400,'Aksi tidak dikenal');
    save();return json(res,200,{ok:1})}
  if(m==='GET'&&p==='/api/board'){const since=Date.now()-6048e5,g={},r={};for(const x of db.gl)if(x.ts>=since){g[x.f]=(g[x.f]||0)+x.c;r[x.t]=(r[x.t]||0)+x.c}
    const top=o=>Object.entries(o).filter(([k])=>db.users[k]).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([k,c])=>({u:k,c}));
    return json(res,200,{givers:top(g),receivers:top(r),rich:Object.values(db.users).sort((a,b)=>b.coins-a.coins).slice(0,10).map(x=>({u:x.u,c:x.coins}))})}
  if(m==='GET'&&p==='/api/owner/reports'){if(!u.owner)fail(403,'Khusus owner');return json(res,200,{reports:db.reports.filter(x=>!x.done).slice(-50).reverse()})}
  if(m==='POST'&&p==='/api/owner/report'){if(!u.owner)fail(403,'Khusus owner');const b=await readBody(req,1e3),r=db.reports.find(x=>x.id===+b.id);if(r)r.done=1;save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/owner/ban'){if(!u.owner)fail(403,'Khusus owner');const b=await readBody(req,1e3),t=db.users[str(b.u,20)];if(!t||t.owner)fail(400,'Tidak valid');t.ban=t.ban?0:1;if(t.ban)for(const k in db.tokens)if(db.tokens[k]===t.u)delete db.tokens[k];save();return json(res,200,{ok:1})}
  if(m==='POST'&&p==='/api/owner/atur'){if(!u.owner)fail(403,'Khusus owner');const b=await readBody(req,1e3),t=db.users[str(b.u,20)];if(!t)fail(400,'Tidak valid');
    const fcnt=Object.values(db.users).filter(y=>y.fol.includes(t.u)).length,lcnt=db.posts.reduce((a,q)=>q.u===t.u?a+q.by.length:a,0),cl=x=>Math.max(0,Math.min(1e9,Math.round(+x||0))),off=x=>Math.max(-1e9,Math.min(1e9,Math.round(+x||0)));
    if(b.reset){t.fb=0;t.lb=0}
    else if(b.ft!==undefined||b.lt!==undefined){if(b.ft!==undefined)t.fb=cl(b.ft)-fcnt;if(b.lt!==undefined)t.lb=cl(b.lt)-lcnt}
    else{t.fb=off(b.f);t.lb=off(b.l)}
    save();return json(res,200,{ok:1})}
  fail(404,'Endpoint tidak ada')}
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.svg':'image/svg+xml','.ico':'image/x-icon','.mp4':'video/mp4','.webm':'video/webm','.weba':'audio/webm','.mov':'video/quicktime','.ogg':'audio/ogg','.m4a':'audio/mp4','.mp3':'audio/mpeg','.wav':'audio/wav'};
function serve(req,res,file,cache){fs.stat(file,(e,st)=>{
  if(e||!st.isFile()){res.writeHead(404,CORS);return res.end('Tidak ditemukan')}
  const h={...CORS,'Content-Type':MIME[path.extname(file).toLowerCase()]||'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':cache,'Accept-Ranges':'bytes'};
  const rg=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range||'');
  if(rg&&(rg[1]||rg[2])){const s=rg[1]?+rg[1]:Math.max(0,st.size-+rg[2]),en=rg[1]&&rg[2]?Math.min(+rg[2],st.size-1):st.size-1;
    if(s>en||s>=st.size){res.writeHead(416,{...h,'Content-Range':'bytes */'+st.size});return res.end()}
    res.writeHead(206,{...h,'Content-Range':`bytes ${s}-${en}/${st.size}`,'Content-Length':en-s+1});return fs.createReadStream(file,{start:s,end:en}).pipe(res)}
  res.writeHead(200,{...h,'Content-Length':st.size});fs.createReadStream(file).pipe(res)})}
http.createServer(async(req,res)=>{try{
  const url=new URL(req.url,'http://x'),p=decodeURIComponent(url.pathname);
  if(req.method==='OPTIONS'){res.writeHead(204,CORS);return res.end()}
  if(p.startsWith('/api/'))return await handleApi(req,res,url);
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405,CORS);return res.end()}
  if(p.startsWith('/uploads/'))return serve(req,res,path.join(UP,path.basename(p)),'public, max-age=31536000, immutable');
  const f=path.normalize(path.join(PUB,p==='/'?'index.html':p));if(!f.startsWith(PUB)){res.writeHead(403);return res.end()}
  return serve(req,res,f,'no-cache')
}catch(e){try{json(res,e.code&&e.code<600?e.code:500,{error:e.code?e.message:'Kesalahan server'});if(!e.code)console.error(e)}catch(_){}}}).listen(PORT,()=>console.log('XoltApp berjalan di port '+PORT));
