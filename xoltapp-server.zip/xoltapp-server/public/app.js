
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const jam=()=>new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
const S={tab:'feed',open:null,gift:false,rec:false,cm:{},am:'login',md:null,ed:null,sp:null,rooms:[],ri:null,acc:{},cur:null,me:null,posts:[],stories:[],chats:{global:[]},ver:0,keep:0,off:false,pr:{},ty:{},skew:0,reads:{},shop:[],rpt:[],sig:'',rp:null,em:null,mm:null,pu:null,fl:null,pm:0,qs:'',svis:false,bd:null};
Object.defineProperty(S,'users',{get(){const o={};for(const k in S.acc)if(k!==S.cur)o[k]=Object.assign({},S.acc[k],{f:S.me&&S.me.fol.includes(k)?1:0});return o}});
const sk=k=>k==='global'||String(k).startsWith('r:')?k:[S.cur,k].sort().join('|');
const GIFTS=[['🌹','Mawar',10],['☕','Kopi',20],['❤️','Hati',50],['👑','Mahkota',200],['🚀','Roket',500],['💎','Berlian',1000]];
function save(){try{localStorage.setItem('xolt_tema',document.documentElement.dataset.t)}catch(e){}}
function setTema(t){document.documentElement.dataset.t=t;document.querySelectorAll('[data-a=tema]').forEach(b=>b.classList.toggle('on',b.dataset.v===t));save()}
function toast(m){document.querySelectorAll('.toast').forEach(x=>x.remove());const d=document.createElement('div');d.className='toast';d.textContent=m;$('#app').appendChild(d);setTimeout(()=>d.remove(),1800)}
const avh=u=>(u&&u.pic?`<img src="${mu(u.pic)}" alt="">`:(u?esc(u.av||'🙂'):'👤'))+(u&&u.fr?`<i class="frm ${u.fr}"></i>`:'')+(u&&u.u&&isOn(u.u)?'<i class="dot"></i>':'');
const nama=id=>String(id).startsWith('r:')?roomU(id):S.acc[id]||{n:'(akun dihapus)',av:'👤'};
const VB='<svg class="vb" viewBox="0 0 24 24" role="img" aria-label="Terverifikasi"><g fill="#1D9BF0"><rect x="4" y="4" width="16" height="16" rx="4.5"/><rect x="4" y="4" width="16" height="16" rx="4.5" transform="rotate(45 12 12)"/></g><path d="M8 12.4l2.8 2.8 5.3-5.6" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const vname=u=>esc(u.n)+(u.v?' <span class="ck">'+VB+'</span>':'');
function shrink(file,max,cb){const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);cb(c.toDataURL('image/jpeg',.82))};im.onerror=()=>toast('Foto tidak bisa dibaca');im.src=r.result};r.readAsDataURL(file)}
function sampul(file,cb){shrink(file,1080,cb)}
const BOLT='<svg class="bolt" viewBox="0 0 24 24" aria-hidden="true"><path d="M13.5 1 4 13.5h6.2L9 23l10.5-13.2h-6.4z" fill="#FFD21F" stroke="#7A0010" stroke-width="1.3" stroke-linejoin="round"/></svg>';
const avw=(u,st)=>`<div class="av"${st||''}>${avh(u)}</div>`;
const ago=t=>{const m=Math.floor((Date.now()-t)/6e4);return m<1?'baru saja':m<60?m+' mnt lalu':m<1440?Math.floor(m/60)+' jam lalu':Math.floor(m/1440)+' hari lalu'};
function trayHTML(){const now=Date.now();
  S.stories.forEach(s=>{s.t=s.t||now;s.id=s.id||String(now+Math.random())});
  const old=S.stories.filter(s=>now-s.t>=864e5);
  if(old.length){S.stories=S.stories.filter(s=>now-s.t<864e5);}
  const by={};S.stories.forEach(s=>(by[s.u]=by[s.u]||[]).push(s));
  const us=Object.keys(by).sort((a,b)=>a===S.cur?-1:b===S.cur?1:Math.max(...by[b].map(x=>x.t))-Math.max(...by[a].map(x=>x.t)));
  return `<div class="stories"><div class="st" data-a="tambahstory"><div class="ring add">${avw(S.me)}<b class="plus">+</b></div>Tambah</div>`
   +us.map(u=>{const un=by[u].some(x=>!(x.seen||[]).includes(S.cur));return `<div class="st" data-a="story" data-u="${esc(u)}"><div class="ring ${un?'':'seen'}">${avw(nama(u))}</div>${esc(u===S.cur?'Ceritamu':nama(u).n)}</div>`}).join('')+'</div>'}
function modalHTML(){const m=S.md;if(!m)return '';let b='';
  if(m==='edit'){const e=S.ed||{},u=Object.assign({},S.me,{pic:e.pic===undefined?S.me.pic:e.pic});
    b=`<h3>Edit profil</h3><div style="text-align:center">${avw(u,' style="width:88px;height:88px;font-size:46px;margin:auto"')}
    <div class="row" style="justify-content:center;margin:10px 0"><label class="btn">📷 Ganti foto<input id="ef" type="file" accept="image/*" class="fi"></label>${u.pic?'<button class="btn" data-a="efhapus">Hapus foto</button>':''}</div></div>
    <input id="en" maxlength="30" placeholder="Nama" value="${esc(e.n===undefined?S.me.n:e.n)}" style="margin-bottom:8px"><input id="eb" maxlength="120" placeholder="Bio" value="${esc(e.b===undefined?S.me.bio:e.b)}">
    <div class="row" style="margin-top:12px"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="esimpan">Simpan</button></div>`}
  else if(m==='story'){const p=S.sp||{};
    b=`<h3>Buat cerita</h3>${p.k==='img'?`<img class="pv" src="${p.d}" alt="">`:p.k==='vid'?`<video class="pv" src="${p.url}" controls muted playsinline></video>`:'<div class="pv">⚡<small class="mu">Pilih foto/video atau tulis teks saja</small></div>'}
    <div class="row" style="margin:8px 0"><label class="btn">🖼️ Foto / Video<input id="sf" type="file" accept="image/*,video/*" class="fi"></label>${p.k?'<button class="btn" data-a="sclear">Ganti</button>':''}</div>
    <input id="sc" maxlength="150" placeholder="Tulis keterangan..." value="${esc(p.c||'')}"><label class="row" style="margin:8px 0"><input type="checkbox" id="sv" style="width:auto" ${S.svis?'checked':''}> 🔒 Hanya teman (saling simpan)</label>
    <div class="row" style="margin-top:12px"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="sbagi">Bagikan</button></div>`}
  else if(m==='room'){const o=Object.keys(S.users);
    b=`<h3>Buat grup / channel</h3><input id="rn" class="au" maxlength="30" placeholder="Nama"><select id="rt" class="au"><option value="g">👥 Grup (anggota dipilih)</option><option value="c">📢 Channel (hanya kamu yang kirim)</option></select><select id="rv" class="au"><option value="0">🔒 Privat — hanya yang diundang</option><option value="1">🌐 Publik — semua bisa gabung</option></select>
    <div id="rm">${o.length?o.map(u=>`<label class="row" style="margin:6px 0"><input type="checkbox" value="${esc(u)}" style="width:auto"> ${esc(nama(u).n)} <span class="mu">@${esc(u)}</span></label>`).join(''):'<p class="mu">Belum ada pengguna lain untuk ditambahkan.</p>'}</div>
    <div class="row" style="margin-top:12px"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="rsimpan">Buat</button></div>`}
  else if(m==='rinfo'){const r=room(S.ri);if(!r)return '';const adm=isAdm(r),cr=r.o===S.cur,u0=roomU(r.id),mem=r.off?[r.o]:r.m,rl=x=>x===r.o?'Pembuat':(r.ad||[]).includes(x)?'Admin':'Anggota',outs=Object.keys(S.acc).filter(x=>!r.m.includes(x));
    b=`<h3>${r.t==='c'?'Info channel':'Info grup'}</h3><div style="text-align:center"><div class="av" style="width:88px;height:88px;font-size:46px;margin:auto">${avh(u0)}</div>
    ${adm?`<div class="row" style="justify-content:center;margin:10px 0"><label class="btn">📷 Ganti foto<input id="rf" type="file" accept="image/*" class="fi"></label>${r.pic?'<button class="btn" data-a="rfhapus">Hapus foto</button>':''}</div>
    <div class="row"><input id="rnn" class="au" maxlength="30" value="${esc(r.n)}" style="margin:0"><button class="btn pr" data-a="rnsimpan">Simpan</button></div>`:`<h3 style="margin-top:8px">${vname(u0)}</h3>`}</div>
    ${r.off?'':`<div class="row" style="margin-top:10px"><span class="mu" style="flex:1">${isPubR(r)?'🌐 Publik (siapa saja bisa gabung)':'🔒 Privat (hanya yang diundang)'}</span>${adm?'<button class="btn" data-a="rvis">Ubah</button>':''}</div>`}<h3 style="margin-top:12px">${r.off?'Pembuat':'Anggota ('+mem.length+')'}</h3>
    ${mem.map(x=>{const a=S.acc[x];if(!a)return '';const isA=(r.ad||[]).includes(x),me=x===S.cur;
      return `<div class="row" style="margin:8px 0"><div class="av">${avh(a)}</div><div style="flex:1"><div class="nm">${vname(a)}${me?' (kamu)':''}</div><div class="mu">${rl(x)}</div></div>${adm&&!me&&x!==r.o&&!r.off?`${isA?(cr?`<button class="btn" data-a="rcopot" data-u="${esc(x)}">Copot admin</button>`:''):`<button class="btn" data-a="radm" data-u="${esc(x)}">Jadi admin</button>`}${isA&&!cr?'':`<button class="btn" data-a="rkick" data-u="${esc(x)}">Keluarkan</button>`}`:''}</div>`}).join('')}
    ${adm&&!r.off&&outs.length?`<h3 style="margin-top:12px">Tambah anggota</h3>${outs.map(x=>`<div class="row" style="margin:8px 0"><div class="av">${avh(S.acc[x])}</div><div style="flex:1"><div class="nm">${esc(S.acc[x].n)}</div><div class="mu">@${esc(x)}</div></div><button class="btn pr" data-a="rtambah" data-u="${esc(x)}">Tambah</button></div>`).join('')}`:''}
    <div class="row" style="margin-top:14px">${!cr&&!r.off&&r.m.includes(S.cur)?'<button class="btn" style="flex:1" data-a="rkeluar">Keluar</button>':''}<button class="btn pr" style="flex:1" data-a="mx">Tutup</button></div>`}
  else if(m==='out'){
    b=`<h3>Keluar dari akun?</h3><p class="mu" style="margin:6px 0 12px">Kamu masuk sebagai @${esc(S.cur)}. Datamu tetap tersimpan dan bisa masuk lagi kapan saja.</p>
    <div class="row"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="keluarok">Ya, keluar</button></div>`}
  return `<div class="md" data-a="mbg"><div class="mb">${b}</div></div>`}

const isAdm=r=>r.o===S.cur||(r.ad||[]).includes(S.cur);
const isRoom=k=>String(k).startsWith('r:'),room=id=>S.rooms.find(r=>r.id===id);
function roomU(id){const r=room(id);return r?{n:r.n,pic:r.pic,av:r.t==='c'?'📢':'👥',v:r.off?1:0,bio:r.t==='c'?'Channel':'Grup'}:{n:'(dihapus)',av:'👥'}}
const noPost=k=>{const r=isRoom(k)&&room(k);return !!(r&&r.t==='c'&&!isAdm(r))};
function authView(){
  $('#nav').innerHTML='';$('#ovl').innerHTML='';const reg=S.am==='reg';
  $('#v').style.padding='';$('#v').innerHTML=`<div class="brand">${BOLT}<h2>XoltApp</h2><p class="mu">Cepat seperti petir</p></div><div class="card"><h3>${reg?'Buat akun':'Masuk'}</h3>
  ${reg?'<input id="an" class="au" placeholder="Nama Biasa" maxlength="30">':''}
  <input id="au" class="au" placeholder="Username (huruf kecil/angka/_)" autocapitalize="none" autocomplete="username" maxlength="20">
  <input id="ap" class="au" type="password" placeholder="Kata sandi (min. 6)" autocomplete="${reg?'new-password':'current-password'}">
  <div class="row" style="margin-top:8px"><button class="btn pr" data-a="auth">${reg?'Daftar':'Masuk'}</button><button class="btn" data-a="amode">${reg?'Sudah punya akun':'Belum punya akun? Buat'}</button></div>
  <p class="mu">Akunmu tersimpan di server XoltApp, jadi bisa dibuka dari HP mana saja.</p></div>`}
async function doAuth(){const u=$('#au').value.trim().toLowerCase(),p=$('#ap').value;
  if(!/^[a-z0-9_]{3,20}$/.test(u))return toast('Username 3-20 karakter: huruf kecil, angka, _');
  if(p.length<6)return toast('Sandi minimal 6 karakter');
  try{const reg=S.am==='reg',d=await api(reg?'/api/register':'/api/login','POST',{u,p,n:reg?($('#an').value.trim()||u):undefined});
    TOKEN=d.token;try{localStorage.setItem('xolt_token',TOKEN)}catch(e){}
    S.md=null;S.tab='feed';S.open=null;S.am='login';await pull(true);toast('Selamat datang, '+(S.me?S.me.n:u))}
  catch(e){toast(e.message)}}
function render(){
  if(!S.me)return authView();
  const T=[['feed','🏠','Beranda'],['chat','💬','Chat'],['global','🌍','Global'],['me','👤','Profil']];
  if(S.me.owner)T.splice(3,0,['owner','🛡️','Owner']);
  $('#nav').innerHTML=T.map(t=>`<button data-a="tab" data-v="${t[0]}" class="${S.tab===t[0]?'on':''}"><i>${t[1]}</i>${t[2]}${tabBadge(t[0])}</button>`).join('');
  const v=$('#v');v.style.padding=S.tab==='global'?'0':'';
  v.innerHTML=S.tab==='feed'?feedView():S.tab==='owner'&&S.me.owner?ownerView():S.tab==='chat'?listView():S.tab==='global'?`<div style="height:100%">${chatView('global',1)}</div>`:profView();
  let o='';
  if(S.open){const u=nama(S.open);o=`<div class="ov"><header><button class="btn" data-a="tutup">←</button><h1${isRoom(S.open)?'':` data-a="profil" data-u="${esc(S.open)}"`}>${esc(u.n)}${chatStatus(S.open)}</h1>${isRoom(S.open)?`<button class="btn" data-a="rinfo" data-i="${S.open}" aria-label="Info">ⓘ</button>`:'<button class="btn" data-a="telp" aria-label="Telepon">📞</button>'}</header>${chatView(S.open,isRoom(S.open)?1:0)}</div>`}
  if(S.gift)o+=`<div class="sh"><div class="row"><h3 style="flex:1">Kirim Hadiah</h3><span>🪙 ${S.me.coins}</span><button class="btn" data-a="gtutup">✕</button></div>
   <div class="gg">${GIFTS.map((g,i)=>`<button class="btn" data-a="kadogo" data-i="${i}" ${S.me.coins<g[2]?'disabled style="opacity:.4"':''}><div class="big">${g[0]}</div>${g[1]}<br><small>${g[2]} koin</small></button>`).join('')}</div></div>`;
  $('#ovl').innerHTML=o+modalHTML();
  const ms=$('#ms');if(ms)ms.scrollTop=ms.scrollHeight;
}
let V=null;
function storyClose(quiet){if(V){clearTimeout(V.t);if(V.url)URL.revokeObjectURL(V.url)}V=null;const o=document.querySelector('.sv2');if(o)o.remove();if(!quiet)render()}
function storyOpen(u){const list=S.stories.filter(s=>s.u===u).sort((a,b)=>a.t-b.t);if(!list.length)return;
  const f=list.findIndex(s=>!(s.seen||[]).includes(S.cur));V={u,list,i:f<0?0:f,t:0,url:null};storyShow()}
async function storyShow(){
  if(!V)return;clearTimeout(V.t);if(V.url){URL.revokeObjectURL(V.url);V.url=null}
  const my=V.i,s=V.list[my];if(!s)return storyClose();
  s.seen=s.seen||[];if(!s.seen.includes(S.cur)){s.seen.push(S.cur);api('/api/stories/'+s.id+'/seen','POST',{}).catch(()=>{})}
  let media='',vid=false;
  if(s.vid){vid=true;media=`<video id="svv" src="${mu(s.vid)}" autoplay playsinline></video>`}
  else if(s.img)media=`<img src="${mu(s.img)}" alt="">`;
  const us=nama(s.u),mine=s.u===S.cur,dur=s.img?5:4;
  const bars=V.list.map((x,j)=>`<span><i ${j===my?'id="pb"':''} class="${j<my?'full':''}" ${j===my&&!vid?`style="animation:go ${dur}s linear forwards"`:''}></i></span>`).join('');
  let o=document.querySelector('.sv2');if(!o){o=document.createElement('div');o.className='sv2';$('#app').appendChild(o)}
  o.innerHTML=`<div class="pgs">${bars}</div><div class="shd">${avw(us)}<div><b>${vname(us)}${s.vis==='priv'?' 🔒':''}</b><div class="mu2">${ago(s.t)}${mine?' · 👁 '+(s.seen||[]).filter(x=>x!==S.cur).length+(s.gf?' · 🎁 '+s.gf:''):''}</div></div><span style="flex:1"></span>${mine?'<button data-a="sdel" aria-label="Hapus cerita">🗑</button>':'<button data-a="sgift" aria-label="Hadiah">🎁</button>'}<button data-a="sx" aria-label="Tutup">✕</button></div>
  <div class="smed${s.img||s.vid?'':' txt'}">${media}${s.txt?`<p class="cap">${esc(s.txt)}</p>`:''}</div>${V.gp?giftBar():''}<div class="tz l" data-a="sprev"></div><div class="tz r" data-a="snext"></div>`;
  if(vid){const v=document.getElementById('svv'),pb=document.getElementById('pb');
    v.onloadedmetadata=()=>{pb.style.animation='go '+(v.duration||5)+'s linear forwards'};
    v.onended=()=>storyKey('snext');v.play().catch(()=>{v.muted=true;v.play().catch(()=>{})})}
  else if(!V.gp)V.t=setTimeout(()=>storyKey('snext'),dur*1000)}
function storyKey(a){if(!V)return;
  if(a==='sx')return storyClose();
  if(a==='snext'){if(V.i>=V.list.length-1)return storyNextUser();V.i++;return storyShow()}
  if(a==='sprev'){V.i=Math.max(0,V.i-1);return storyShow()}
  if(a==='sdel'){const s=V.list[V.i];api('/api/stories/'+s.id,'DELETE').then(()=>pull(true)).catch(e=>toast(e.message));V.list.splice(V.i,1);toast('Cerita dihapus');
    if(!V.list.length)return storyClose();V.i=Math.min(V.i,V.list.length-1);storyShow()}}
function storyPick(f,c){
  if(f.type.startsWith('video/')){if(f.size>25*1048576)return toast('Video maksimal 25 MB');
    if(S.sp&&S.sp.url)URL.revokeObjectURL(S.sp.url);S.sp={k:'vid',blob:f,url:URL.createObjectURL(f),c};render()}
  else if(f.type.startsWith('image/'))shrink(f,1080,d=>{S.sp={k:'img',d,c};render()});
  else toast('Pilih file foto atau video')}
async function storyPost(){const txt=($('#sc').value||'').trim(),p=S.sp||{};
  if(!p.k&&!txt)return toast('Pilih foto/video atau tulis sesuatu');
  toast('Mengunggah...');
  try{const body={txt:txt.slice(0,150),vis:($('#sv')&&$('#sv').checked)?'priv':'pub'};if(p.k==='img')body.img=await upload(p.d);if(p.k==='vid')body.vid=await upload(p.blob);
    await api('/api/stories','POST',body);if(p.url)URL.revokeObjectURL(p.url);S.sp=null;S.md=null;S.svis=false;await pull(true);toast('Cerita dibagikan ⚡')}
  catch(e){toast(e.message)}}
function logout(){api('/api/logout','POST',{}).catch(()=>{});localLogout();toast('Kamu sudah keluar')}

document.addEventListener('click',e=>{
  const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,i=b.dataset.i;
  if(a==='mx'){if(S.sp&&S.sp.url)URL.revokeObjectURL(S.sp.url);S.md=null;S.ed=null;S.sp=null;return render()}
  if(a==='mbg'){if(e.target===b){if(S.sp&&S.sp.url)URL.revokeObjectURL(S.sp.url);S.md=null;S.ed=null;S.sp=null;render()}return}
  if(a==='tambahstory'){S.md='story';S.sp=null;return render()}
  if(a==='edit'){S.md='edit';S.ed=null;return render()}
  if(a==='keluar'){S.md='out';return render()}
  if(a==='keluarok')return logout();
  if(a==='efhapus'){S.ed={n:$('#en').value,b:$('#eb').value,pic:null};return render()}
  if(a==='esimpan'){const n=$('#en').value.trim(),bi=$('#eb').value.trim();if(!n)return toast('Nama tidak boleh kosong');
    (async()=>{try{const body={n,bio:bi};if(S.ed&&S.ed.pic!==undefined)body.pic=S.ed.pic?await upload(S.ed.pic):null;
      await api('/api/me','PUT',body);S.md=null;S.ed=null;await pull(true);toast('Profil disimpan')}catch(e){toast(e.message)}})();return}
  if(a==='sclear'){if(S.sp&&S.sp.url)URL.revokeObjectURL(S.sp.url);S.sp={c:$('#sc').value};return render()}
  if(a==='sbagi')return storyPost();
  if(a==='sprev'||a==='snext'||a==='sx'||a==='sdel')return storyKey(a);
  if(a==='rbuat'){S.md='room';return render()}
  if(a==='rsimpan'){const n=$('#rn').value.trim();if(!n)return toast('Isi nama dulu');const t=$('#rt').value,m=[...document.querySelectorAll('#rm input:checked')].map(x=>x.value);
    if(t==='g'&&!m.length&&!+$('#rv').value)return toast('Pilih minimal 1 anggota untuk grup privat');
    act('/api/rooms',{n,t,m,pub:+$('#rv').value}).then(r=>{if(r&&r.id){S.md=null;S.open=r.id;render()}});return}
  if(a==='rgabung'){act('/api/rooms/'+i+'/join');return}
  if(a==='umum'){if(!S.me.owner)return;const t=$('#an').value.trim();if(!t)return toast('Tulis pengumuman dulu');$('#an').value='';act('/api/owner/announce',{t}).then(()=>toast('Pengumuman terkirim'));return}
  if(a==='ckb'){act('/api/owner/verify',{u:i});return}
  if(a==='rinfo'){S.md='rinfo';S.ri=i;return render()}
  if(['radm','rcopot','rkick','rtambah','rkeluar','rnsimpan','rfhapus'].includes(a)){const u=b.dataset.u,id=S.ri;
    const map={radm:{op:'adm',u},rcopot:{op:'copot',u},rkick:{op:'kick',u},rtambah:{op:'add',u},rkeluar:{op:'leave'},rnsimpan:{op:'name',n:($('#rnn')||{}).value},rfhapus:{op:'pic',pic:null}};
    if(a==='rkeluar'){S.md=null;S.open=null}
    act('/api/rooms/'+id+'/op',map[a]);return}
  if(a==='auth')return doAuth();
  if(a==='amode'){S.am=S.am==='reg'?'login':'reg';return render()}
  if(a==='tema')return setTema(b.dataset.v);
  if(a==='tab'){S.tab=b.dataset.v;return render()}
  if(a==='suka'){act('/api/posts/'+i+'/like');return}
  if(a==='cm'){S.cm[i]=!S.cm[i];return render()}
  if(a==='kirimcm'){const el=$('#ci'+i),t=el.value.trim();if(t){el.value='';act('/api/posts/'+i+'/comments',{t})}return}
  if(a==='hapus'){act('/api/posts/'+i,null,'DELETE');return}
  if(a==='bagi'){const p=S.posts.find(x=>x.id==i),tx=nama(p.u).n+': '+p.t;
    if(navigator.share)navigator.share({text:tx}).catch(()=>{});else{try{navigator.clipboard.writeText(tx);toast('Teks disalin')}catch(_){toast('Tidak bisa menyalin')}}return}
  if(a==='hapusfoto'){act('/api/me',{pic:null},'PUT');return}
  if(a==='story')return storyOpen(b.dataset.u);
  if(a==='buka'){S.open=i;return render()}
  if(a==='tutup'){S.open=null;S.rec=false;return render()}
  if(a==='telp')return toast('Panggilan suara/video ada di versi Flutter');
  if(a==='gift'){S.gift=true;return render()}
  if(a==='gtutup'){S.gift=false;return render()}
  if(a==='kadogo'){const g=GIFTS[i];if(S.me.coins<g[2])return toast('Koin tidak cukup');
    act('/api/gift',{to:S.open,i:+i}).then(()=>{S.gift=false;render();toast('Hadiah '+g[1]+' terkirim')});return}
  if(a==='vn')return S.rec?vnStop(true):vnStart();
  if(a==='vnx')return vnStop(false);
  if(a==='vnp')return vnPlay(b.dataset.u);
  if(a==='kirim'){const k=b.dataset.k,el=$('#ci');return kirim(k,el.value)}
  if(a==='ikuti'){act('/api/follow',{u:i});return}
});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.target.id==='au'||e.target.id==='ap')){e.preventDefault();return doAuth()}
  if(e.key==='Enter'&&e.target.id==='ci'&&!e.shiftKey){e.preventDefault();kirim(e.target.dataset.k,e.target.value)}});
document.addEventListener('change',e=>{const t=e.target,f=t.files&&t.files[0];
  if(t.id==='pf'){$('#pn').textContent=t.files.length>1?t.files.length+' file dipilih':(f?f.name:'');return}
  if(!f)return;
  if(t.id==='pp'){t.value='';return shrink(f,256,async d=>{try{const url=await upload(d);await api('/api/me','PUT',{pic:url});await pull(true);toast('Foto profil diganti')}catch(e){toast(e.message)}})}
  if(t.id==='rf'){const r=room(S.ri);if(r&&isAdm(r))shrink(f,256,async d=>{try{const url=await upload(d);await api('/api/rooms/'+S.ri+'/op','POST',{op:'pic',pic:url});await pull(true)}catch(e){toast(e.message)}});return}
  if(t.id==='ef'){S.ed=Object.assign(S.ed||{},{n:$('#en').value,b:$('#eb').value});shrink(f,256,d=>{S.ed.pic=d;render()})}
  if(t.id==='sf')storyPick(f,$('#sc').value)});
document.addEventListener('keydown',e=>{if(!V)return;if(e.key==='Escape')storyKey('sx');if(e.key==='ArrowRight')storyKey('snext');if(e.key==='ArrowLeft')storyKey('sprev')});
window.addEventListener('error',e=>{try{toast('Terjadi kesalahan, coba lagi')}catch(_){}});
let tema='xolt';try{tema=localStorage.getItem('xolt_tema')||'xolt'}catch(e){}
setTema(tema);{const _r=render;render=function(){const k=S.keep;S.keep=0;const s=k?snap():null;_r();if(s)unsnap(s);save();hdr();setTimeout(markRead,0)}}document.addEventListener('DOMContentLoaded',boot);
