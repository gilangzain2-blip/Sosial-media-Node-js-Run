// Alamat server XoltApp.
// Kosongkan ('') jika halaman ini dibuka dari server XoltApp yang sama (paling mudah).
// Jika halaman ini di-hosting terpisah (mis. Netlify), isi dengan alamat HTTPS server, contoh: 'https://api.contoh.com'
window.XOLT_API='';
