// Fitur lanjutan XoltApp: profil & pengikut, notifikasi, pencarian, reaksi, balas/edit/hapus,
// polling, blokir/laporan, bonus harian, toko, peringkat, hadiah di postingan/story, presence.
const EMO=['👍','❤️','😂','😮','😢','🙏'];
const sheet=b=>`<div class="md" data-a="mbg"><div class="mb">${b}</div></div>`;
const closeRow='<div class="row" style="margin-top:12px"><button class="btn pr" style="flex:1" data-a="mx">Tutup</button></div>';
const rich=t=>esc(t==null?'':t).replace(/(^|\s)(@[a-z0-9_]{3,20})/g,(m,a,b)=>a+'<a class="mn" data-a="profil" data-u="'+b.slice(1)+'">'+b+'</a>').replace(/(^|\s)(#[\p{L}\p{N}_]{2,30})/gu,(m,a,b)=>a+'<a class="mn" data-a="tag" data-t="'+b+'">'+b+'</a>');
const isPubR=r=>!!(r.off||(r.pub===undefined?r.t==='c':r.pub));
const isOn=u=>u===S.cur||((Date.now()+(S.skew||0))-((S.pr||{})[u]||0))<25000;
const lastSeen=u=>(S.pr||{})[u]?ago((S.pr||{})[u]-(S.skew||0)):'belum pernah online';
const unread=k=>{const rd=((S.me&&S.me.rd)||{})[k]||0;return(S.chats[k]||[]).filter(m=>m.id>rd&&m.f!==S.cur&&!m.del).length};
const unreadChats=()=>Object.keys(S.chats).reduce((n,k)=>k==='global'?n:n+unread(k),0);
const bdg=n=>n>0?`<b class="bd">${n>99?'99+':n}</b>`:'';
const curKey=()=>S.open?sk(S.open):'global';
function tabBadge(t){return t==='chat'?bdg(unreadChats()):t==='global'?bdg(unread('global')):t==='me'&&S.me.dly&&S.me.dly.can?'<b class="bd">!</b>':''}
function hdr(){const h=document.querySelector('.hic');if(h)h.style.display=S.me?'flex':'none';const g=$('#hgc');if(g)g.hidden=!(S.me&&S.me.owner);
  const nb=$('#nb');if(nb){const n=S.me?(S.me.nf||[]).filter(x=>x.ts>(S.me.nr||0)).length:0;nb.hidden=!n;nb.textContent=n>99?'99+':n}}
function markRead(){if(!S.me||document.hidden)return;const k=S.open?sk(S.open):(S.tab==='global'&&!S.md?'global':null);if(!k)return;
  const l=S.chats[k]||[];if(l.length&&unread(k)>0){S.me.rd=S.me.rd||{};S.me.rd[k]=l[l.length-1].id;api('/api/read','POST',{k}).catch(()=>{});S.keep=1;render()}}
function chatStatus(k){if(isRoom(k)){const r=room(k);return r?`<small>${r.off?'Channel resmi':r.m.length+' anggota'}</small>`:''}
  return isOn(k)?'<small class="onl">● online</small>':`<small>terakhir dilihat ${lastSeen(k)}</small>`}
let _tl=0;function typing(k){if(Date.now()-_tl<2500)return;_tl=Date.now();api('/api/typing','POST',{k:sk(k)}).catch(()=>{})}

// ---------- pesan ----------
function bubbles(key,glob){const k=sk(key),pair=!glob&&!isRoom(key);
  return (S.chats[k]||[]).map(m=>{const me=m.f===S.cur;let body;
    if(m.del)body='<i class="mu">🚫 Pesan dihapus</i>';
    else if(m.g)body=`<div class="big">${m.g[0]}</div><b>Hadiah ${m.g[1]}</b><br><span class="mu">${m.g[2]} koin</span>`;
    else if(m.vn&&m.vn.url)body=`<button class="btn" data-a="vnp" data-u="${esc(m.vn.url)}">${VNA.u===m.vn.url&&VNA.p?'⏸':'▶'} 🎤 ${fmtd(m.vn.d)}</button>`;
    else body=rich(m.t);
    const re=m.re?`<div class="rq"><b>${esc(nama(m.re.f).n)}</b><br>${esc(m.re.t||'')}</div>`:'';
    const rx=m.rx&&Object.keys(m.rx).length?`<div class="rxs">${Object.entries(m.rx).map(([e,l])=>`<span class="rxc ${l.includes(S.cur)?'me':''}" data-a="rx" data-i="${m.id}" data-e="${e}">${e} ${l.length}</span>`).join('')}</div>`:'';
    const tk=me&&pair&&!m.del?((S.reads[k]||0)>=m.id?'<span class="tk r">✓✓</span>':'<span class="tk">✓</span>'):'';
    return `<div class="b ${me?'me':''}" ${m.del?'':`data-a="mm" data-i="${m.id}"`}>${glob&&!me?`<span class="w" data-a="profil" data-u="${esc(m.f)}">${vname(nama(m.f))}</span><br>`:''}${re}${body}${rx}<small>${m.w}${m.ed?' · diedit':''} ${tk}</small></div>`}).join('')}
function chatView(key,glob){const k=sk(key),np=noPost(key),tp=(S.ty||{})[k]||[];
  const rp=S.rp&&S.rp.k===k?`<div class="rpb"><span>↩ Membalas <b>${esc(nama(S.rp.f).n)}</b>: ${esc(S.rp.t)}</span><button class="btn" data-a="rpx">✕</button></div>`:'';
  const ed=S.em&&S.em.k===k?'<div class="rpb"><span>✏️ Mengedit pesan</span><button class="btn" data-a="emx">✕</button></div>':'';
  const ty=tp.length?`<div class="tyl">✍️ ${esc(tp.map(x=>nama(x).n).join(', '))} sedang mengetik...</div>`:'';
  const gift=glob?'':'<button class="btn" data-a="gift" aria-label="Hadiah">🎁</button>';
  const bar=np?'<div class="bar"><span class="mu" style="flex:1;text-align:center">Hanya pembuat channel yang bisa mengirim pesan</span></div>'
    :`<div class="bar">${gift}${S.rec?'<span style="flex:1">🔴 Merekam... ketuk ⏹ untuk kirim</span><button class="btn" data-a="vnx">✕</button>':`<input id="ci" placeholder="${glob?'Pesan... (@nama untuk menyebut)':'Tulis pesan...'}" data-k="${key}" data-g="${glob?1:0}" autocomplete="off">`}<button class="btn" data-a="vn" aria-label="Voice note">${S.rec?'⏹':'🎤'}</button><button class="btn pr" data-a="kirim" data-k="${key}" data-g="${glob?1:0}">Kirim</button></div>`;
  return `<div class="chat"><div class="msgs" id="ms">${bubbles(key,glob)||'<p class="mu" style="text-align:center;margin-top:30px">Belum ada pesan. Sapa duluan!</p>'}</div>${ty}${rp}${ed}${bar}</div>`}
function kirim(key,t){t=t.trim();if(!t)return;if(noPost(key))return toast('Hanya pembuat channel yang bisa mengirim');
  const el=$('#ci');if(el)el.value='';const k=sk(key);
  if(S.em&&S.em.k===k){const em=S.em;S.em=null;return act('/api/msg',{k,id:em.id,t},'PUT')}
  const re=S.rp&&S.rp.k===k?S.rp.id:undefined;S.rp=null;act('/api/chat',{to:key,t,re})}

// ---------- daftar chat ----------
function roomsHTML(){const mine=S.rooms.filter(r=>r.off||r.o===S.cur||r.m.includes(S.cur)),other=S.rooms.filter(r=>!r.off&&r.o!==S.cur&&!r.m.includes(S.cur)&&!(r.bl||[]).includes(S.cur));
  const snip=l=>l?(l.del?'🚫 Pesan dihapus':l.g?'🎁 Hadiah':l.vn?'🎤 Voice note':esc((l.t||'').slice(0,60))):'Belum ada pesan';
  const row=r=>{const u=roomU(r.id),l=(S.chats[r.id]||[]).slice(-1)[0];return `<div class="card row" data-a="buka" data-i="${r.id}" style="cursor:pointer"><div class="av">${avh(u)}</div><div style="flex:1"><div class="nm">${vname(u)} <span class="mu">${r.t==='c'?'Channel':'Grup'}${r.off?'':isPubR(r)?' · Publik':' · Privat'}</span></div><div class="mu">${snip(l)}</div></div>${bdg(unread(r.id))}</div>`};
  return `<div class="row" style="padding:12px 14px 0"><h3 style="flex:1;margin:0">Grup &amp; Channel</h3><button class="btn pr" data-a="rbuat">＋ Buat</button></div>`
   +(mine.length?mine.map(row).join(''):'<p class="mu" style="text-align:center;padding:12px">Belum ada grup atau channel.</p>')
   +(other.length?`<h3 style="padding:8px 14px 0">Jelajah (publik)</h3>`+other.map(r=>`<div class="card row"><div class="av">${avh(roomU(r.id))}</div><div style="flex:1"><div class="nm">${esc(r.n)} <span class="mu">${r.t==='c'?'Channel':'Grup'}</span></div><div class="mu">${r.m.length} anggota</div></div><button class="btn pr" data-a="rgabung" data-i="${r.id}">Gabung</button></div>`).join(''):'')}
function listView(){const ids=Object.keys(S.users),lt=id=>{const l=(S.chats[sk(id)]||[]).slice(-1)[0];return l?l.ts||0:0};ids.sort((a,b)=>lt(b)-lt(a));
  return roomsHTML()+`<h3 style="padding:12px 14px 0">Pesan</h3>`+(ids.length?'':'<p class="mu" style="text-align:center;padding:30px">Belum ada pengguna lain. Buka Chat Global untuk mulai ngobrol.</p>')+ids.map(id=>{const u=S.users[id],k=sk(id),l=(S.chats[k]||[]).slice(-1)[0];
    return `<div class="card row" data-a="buka" data-i="${id}" style="cursor:pointer"><div class="av">${avh(u)}</div><div style="flex:1"><div class="nm">${vname(u)}${u.bk?' <span class="mu">(diblokir)</span>':''}</div><div class="mu">${l?(l.del?'🚫 Pesan dihapus':l.g?'🎁 Hadiah':l.vn?'🎤 Voice note':esc((l.t||'').slice(0,60))):'Ketuk untuk memulai'}</div></div>${bdg(unread(k))}</div>`}).join('')}

// ---------- beranda & postingan ----------
function pollHTML(p){const tot=p.poll.o.reduce((a,o)=>a+o.v.length,0),my=p.poll.o.findIndex(o=>o.v.includes(S.cur));
  return `<div class="poll">${p.poll.o.map((o,i)=>{const pc=tot?Math.round(o.v.length*100/tot):0;return `<div class="po ${my===i?'me':''}" data-a="vote" data-i="${p.id}" data-o="${i}"><i style="width:${pc}%"></i><span>${esc(o.t)}</span><b>${pc}%</b></div>`}).join('')}<div class="mu">${tot} suara</div></div>`}
function postHTML(p){const u=nama(p.u),mine=p.u===S.cur,imgs=p.imgs&&p.imgs.length?p.imgs:(p.img?[p.img]:[]),liked=(p.by||[]).includes(S.cur);
  const media=p.vid?`<video class="pic" src="${mu(p.vid)}" controls playsinline preload="metadata"></video>`:imgs.length?`<div class="pg pg${imgs.length}">${imgs.map(x=>`<img class="pic" src="${mu(x)}" alt="">`).join('')}</div>`:'';
  const rx=p.rx&&Object.keys(p.rx).length?`<div class="rxs">${Object.entries(p.rx).map(([e,l])=>`<span class="rxc ${l.includes(S.cur)?'me':''}" data-a="prx" data-i="${p.id}" data-e="${e}">${e} ${l.length}</span>`).join('')}</div>`:'';
  const cm=S.cm[p.id]?`<div class="cm">${p.c.map(c=>`<p><b>${esc(nama(c.u).n)}</b> ${rich(c.t)}</p>`).join('')||'<p class="mu">Belum ada komentar</p>'}
   <div class="row"><input id="ci${p.id}" placeholder="Tulis komentar..."><button class="btn pr" data-a="kirimcm" data-i="${p.id}">Kirim</button></div></div>`:'';
  return `<div class="card"><div class="row"><div class="av" data-a="profil" data-u="${esc(p.u)}">${avh(u)}</div><div style="flex:1"><div class="nm" data-a="profil" data-u="${esc(p.u)}">${vname(u)}</div><div class="mu">${p.w||'baru saja'}</div></div>
  ${mine||S.me.owner?`<button class="btn" data-a="hapus" data-i="${p.id}" aria-label="Hapus">🗑</button>`:''}</div>
  ${p.t?`<p style="margin-top:8px;white-space:pre-wrap">${rich(p.t)}</p>`:''}${media}${p.poll?pollHTML(p):''}${rx}
  <div class="acts"><button class="btn ${liked?'lk':''}" data-a="suka" data-i="${p.id}">${liked?'❤️':'🤍'} ${(p.by||[]).length}</button>
  <button class="btn" data-a="cm" data-i="${p.id}">💬 ${p.c.length}</button><button class="btn" data-a="preact" data-i="${p.id}">😊</button>
  ${mine?(p.gf?`<span class="btn">🎁 ${p.gf}</span>`:''):`<button class="btn" data-a="pgift" data-i="${p.id}">🎁${p.gf?' '+p.gf:''}</button>`}<button class="btn" data-a="bagi" data-i="${p.id}">↗</button></div>${cm}</div>`}
function bonusHTML(){const d=S.me.dly;return d&&d.can?`<div class="card row"><div style="flex:1"><b>🎁 Bonus harian siap diklaim</b><div class="mu">Masuk tiap hari, bonus makin besar (hari ke-${(d.s||0)+1})</div></div><button class="btn pr" data-a="daily">Klaim</button></div>`:''}
function composerHTML(){return `<div class="card"><textarea id="pt" rows="2" placeholder="Apa yang sedang kamu pikirkan? (pakai @nama atau #tag)"></textarea>
  <div class="pollbox" style="display:none">${[0,1,2,3].map(i=>`<input class="au poi" placeholder="Pilihan ${i+1}" maxlength="40" ${i>1?'style="display:none"':''}>`).join('')}<button class="btn" data-a="pollplus">＋ Pilihan</button></div>
  <div class="row" style="margin-top:8px"><label class="btn">📷 Foto/Video<input id="pf" type="file" accept="image/*,video/*" multiple class="fi"></label><button class="btn" data-a="pollt" aria-label="Polling">📊</button><span class="mu" id="pn" style="flex:1"></span><button class="btn pr" data-a="posting">Kirim</button></div></div>`}
function feedView(){return trayHTML()+bonusHTML()+composerHTML()+(S.posts.length?S.posts.map(postHTML).join(''):'<p class="mu" style="text-align:center;padding:30px">Belum ada postingan. Jadi yang pertama!</p>')}
async function doPost(){const t=$('#pt').value.trim(),fs=[...($('#pf').files||[])],box=document.querySelector('.pollbox'),pollOn=box&&box.style.display!=='none',po=[...document.querySelectorAll('.poi')].map(x=>x.value.trim()).filter(Boolean);
  if(!t&&!fs.length&&!(pollOn&&po.length))return toast('Tulis sesuatu, pilih foto/video, atau buat polling');
  if(pollOn&&po.length<2)return toast('Polling butuh minimal 2 pilihan');
  const vf=fs.find(f=>f.type.startsWith('video/'));if(vf&&vf.size>25*1048576)return toast('Video maksimal 25 MB');
  toast('Mengirim...');
  try{const body={t};
    if(vf)body.vid=await upload(vf);
    else{body.imgs=[];for(const f of fs.filter(f=>f.type.startsWith('image/')).slice(0,4))body.imgs.push(await upload(await new Promise(ok=>shrink(f,1080,ok))))}
    if(pollOn&&po.length>=2)body.poll={o:po};
    $('#pt').value='';await api('/api/posts','POST',body);await pull(true);toast('Postingan terkirim')}catch(e){toast(e.message)}}

// ---------- profil ----------
const statsHTML=x=>`<div class="stats"><div data-a="flist" data-u="${esc(x.u)}" data-t="fing"><b>${x.fg||0}</b><span>Mengikuti</span></div><div data-a="flist" data-u="${esc(x.u)}" data-t="fol"><b>${x.fl||0}</b><span>Pengikut</span></div><div><b>${x.lk||0}</b><span>Suka</span></div></div>`;
function profView(){const m=S.me;
  return `<div class="card" style="text-align:center"><div class="av" style="width:84px;height:84px;font-size:46px;margin:auto">${avh(m)}</div>
   <h3 style="margin-top:8px">${vname(m)}</h3><p class="mu">@${esc(S.cur)}</p><p class="mu">${esc(m.bio||'')}</p>${statsHTML(m)}
   <div class="row" style="justify-content:center;margin:10px 0;flex-wrap:wrap"><span class="btn">🪙 ${m.coins}</span><button class="btn" data-a="shop">🛒 Toko</button><button class="btn" data-a="board">🏆 Peringkat</button></div>
   <label class="btn">📷 Ganti foto<input id="pp" type="file" accept="image/*" class="fi"></label> ${m.pic?'<button class="btn" data-a="hapusfoto">Hapus foto</button> ':''}<button class="btn pr" data-a="edit">Edit profil</button></div>
   ${bonusHTML()}
   <div class="card"><h3>Orang di XoltApp</h3>${Object.keys(S.users).length?'':'<p class="mu">Belum ada pengguna lain.</p>'}${Object.entries(S.users).map(([id,u])=>`<div class="row" style="margin:8px 0"><div class="av" data-a="profil" data-u="${esc(id)}">${avh(u)}</div><div style="flex:1" data-a="profil" data-u="${esc(id)}"><div class="nm">${vname(u)}</div><div class="mu">${esc(u.bio||'')}</div></div><button class="btn ${u.f?'':'pr'}" data-a="ikuti" data-i="${id}">${u.f?'Mengikuti':'Ikuti'}</button></div>`).join('')}</div>
   <div class="card"><h3>Pengaturan</h3><div class="row" style="flex-wrap:wrap"><button class="btn" data-a="pw">🔑 Ganti sandi</button><button class="btn" data-a="deln">🗑 Hapus akun</button><button class="btn" data-a="keluar">Keluar</button></div></div>`}
function ownerView(){const us=Object.keys(S.acc),rp=S.rpt||[];
  return `<div class="card"><h3>🛡️ Panel Owner</h3><p class="mu">Total akun: ${us.length}. Ketuk pengguna untuk atur centang, angka pengikut/suka, dan pembekuan.</p></div>
  <div class="card row"><div style="flex:1"><b>⚡ Gercep</b><div class="mu">Atur angka pengikut &amp; suka dengan cepat</div></div><button class="btn pr" data-a="gercep">Buka</button></div>
  <div class="card"><h3>📢 Pengumuman</h3><textarea id="an" rows="2" maxlength="300" placeholder="Tulis pengumuman untuk semua pengguna..."></textarea><div class="row" style="margin-top:8px"><button class="btn pr" data-a="umum">Umumkan</button></div><p class="mu">Terkirim ke channel XoltApp Resmi dan Chat Global.</p></div>
  <div class="card"><h3>🚩 Laporan (${rp.length})</h3>${rp.length?rp.map(r=>`<div class="row" style="margin:8px 0"><div style="flex:1"><b>@${esc(r.u)}</b> dilaporkan @${esc(r.by)}<div class="mu">${esc(r.reason)}</div></div><button class="btn" data-a="profil" data-u="${esc(r.u)}">Lihat</button><button class="btn" data-a="rdone" data-i="${r.id}">Tutup</button></div>`).join(''):'<p class="mu">Tidak ada laporan.</p>'}</div>
  <div class="card"><h3>👥 Pengguna</h3>${us.map(u=>{const x=S.acc[u];return `<div class="row" style="margin:8px 0" data-a="profil" data-u="${esc(u)}"><div class="av">${avh(x)}</div><div style="flex:1"><div class="nm">${vname(x)}${x.bn?' 🚫':''}</div><div class="mu">@${esc(u)} · ${x.fl} pengikut · ${x.lk} suka</div></div><button class="btn" data-a="gercep" data-u="${esc(u)}">⚡</button></div>`}).join('')}</div>`}

// ---------- modal baru ----------
const ownerBox=x=>`<div class="card" style="margin-top:12px"><b>🛡️ Owner</b><p class="mu">Angka tampil = angka asli + penyesuaian.</p><div class="row"><input id="af" type="number" class="au" value="${x.fb||0}" placeholder="+pengikut"><input id="al" type="number" class="au" value="${x.lb||0}" placeholder="+suka"></div>
  <div class="row" style="flex-wrap:wrap;margin-top:6px"><button class="btn pr" data-a="atur">Simpan angka</button><button class="btn" data-a="gercep" data-u="${x.u}">⚡ Gercep</button><button class="btn" data-a="ckb" data-i="${x.u}">${x.v?'Cabut centang':'Beri centang'}</button><button class="btn" data-a="ban" data-u="${x.u}">${x.bn?'Buka pembekuan':'Bekukan'}</button></div></div>`;
const personRow=y=>`<div class="row" style="margin:8px 0" data-a="profil" data-u="${esc(y.u)}"><div class="av">${avh(y)}</div><div style="flex:1"><div class="nm">${vname(y)}</div><div class="mu">@${esc(y.u)}</div></div></div>`;
function searchHTML(q){q=q.trim().toLowerCase();
  if(!q){const tags={};S.posts.forEach(p=>((p.t||'').match(/#[\p{L}\p{N}_]{2,30}/gu)||[]).forEach(x=>{x=x.toLowerCase();tags[x]=(tags[x]||0)+1}));const top=Object.entries(tags).sort((a,b)=>b[1]-a[1]).slice(0,10);
    return top.length?`<h3 style="margin:10px 0 6px">Tren</h3><div class="row" style="flex-wrap:wrap">${top.map(([t,n])=>`<a class="mn chip" data-a="tag" data-t="${esc(t)}">${esc(t)} · ${n}</a>`).join('')}</div>`:'<p class="mu" style="margin-top:10px">Ketik untuk mencari orang, grup, atau postingan.</p>'}
  const tag=q.startsWith('#'),us=tag?[]:Object.values(S.acc).filter(x=>x.u.includes(q)||(x.n||'').toLowerCase().includes(q)).slice(0,10),
    rs=tag?[]:S.rooms.filter(r=>r.n.toLowerCase().includes(q)).slice(0,10),ps=S.posts.filter(p=>(p.t||'').toLowerCase().includes(q)).slice(0,10);
  return (us.length?'<h3 style="margin:10px 0 4px">Pengguna</h3>'+us.map(personRow).join(''):'')
   +(rs.length?'<h3 style="margin:10px 0 4px">Grup &amp; channel</h3>'+rs.map(r=>`<div class="row" style="margin:8px 0"><div class="av">${avh(roomU(r.id))}</div><div style="flex:1"><div class="nm">${esc(r.n)}</div><div class="mu">${r.m.length} anggota</div></div>${r.m.includes(S.cur)||r.off?`<button class="btn" data-a="rbuka" data-i="${r.id}">Buka</button>`:`<button class="btn pr" data-a="rgabung" data-i="${r.id}">Gabung</button>`}</div>`).join(''):'')
   +(ps.length?'<h3 style="margin:10px 0 4px">Postingan</h3>'+ps.map(postHTML).join(''):'')||'<p class="mu" style="margin-top:10px">Tidak ada hasil.</p>'}
const NOTIF={like:'menyukai postinganmu',follow:'mulai mengikutimu',save:'menyimpan kontakmu',gift:'mengirim hadiah',room:'',report:''};
const gInfo=x=>`Asli: ${x.rf||0} pengikut · ${x.rl||0} suka — sekarang tampil ${x.fl||0} / ${x.lk||0}`;
const gChips=t=>[['+100',100],['+1K',1000],['+10K',10000],['+100K',100000],['−100',-100]].map(([l,n])=>`<button class="btn" data-a="gadd" data-t="${t}" data-n="${n}">${l}</button>`).join('')+`<button class="btn" data-a="gadd" data-t="${t}" data-set="1">Nol</button>`;
const MODALS={
  gercep(){if(!S.me.owner)return '';if(!S.gu||!S.acc[S.gu])S.gu=Object.keys(S.acc).find(k=>k!==S.cur)||S.cur;const x=S.acc[S.gu];
    return sheet(`<h3>⚡ Gercep — atur pengikut &amp; suka</h3><select id="gu" class="au">${Object.values(S.acc).map(y=>`<option value="${esc(y.u)}" ${y.u===S.gu?'selected':''}>${esc(y.n)} (@${esc(y.u)})</option>`).join('')}</select>
      <p class="mu" id="gi">${gInfo(x)}</p>
      <label class="mu">Pengikut yang tampil</label><input id="gf" type="number" min="0" class="au" value="${x.fl||0}"><div class="row chips">${gChips('f')}</div>
      <label class="mu" style="display:block;margin-top:8px">Suka yang tampil</label><input id="gl" type="number" min="0" class="au" value="${x.lk||0}"><div class="row chips">${gChips('l')}</div>
      <div class="row" style="margin-top:14px"><button class="btn pr" style="flex:1" data-a="gapply">⚡ Terapkan</button><button class="btn" data-a="greset">♻️ Asli</button></div>`+closeRow)},
  msg(){const k=S.mm.k,m=(S.chats[k]||[]).find(x=>x.id===S.mm.id);if(!m)return '';const rm=k.startsWith('r:')?room(k):null,mine=m.f===S.cur,canDel=mine||S.me.owner||(rm&&isAdm(rm));
    return sheet(`<div class="emr">${EMO.map(e=>`<button data-a="react" data-e="${e}">${e}</button>`).join('')}</div><div class="row" style="flex-wrap:wrap;margin-top:8px"><button class="btn" data-a="mrep">↩ Balas</button>${m.t?'<button class="btn" data-a="mcopy">📋 Salin</button>':''}${mine&&m.t?'<button class="btn" data-a="medit">✏️ Edit</button>':''}${canDel?'<button class="btn" data-a="mdel">🗑 Hapus</button>':''}</div>`+closeRow)},
  preact(){return sheet(`<h3>Beri reaksi</h3><div class="emr">${EMO.map(e=>`<button data-a="preactgo" data-e="${e}">${e}</button>`).join('')}</div>`+closeRow)},
  pgift(){return sheet(`<div class="row"><h3 style="flex:1">Kirim hadiah</h3><span>🪙 ${S.me.coins}</span></div><div class="gg">${GIFTS.map((g,i)=>`<button class="btn" data-a="pgv" data-i="${i}" ${S.me.coins<g[2]?'disabled style="opacity:.4"':''}><div class="big">${g[0]}</div>${g[1]}<br><small>${g[2]} koin</small></button>`).join('')}</div>`+closeRow)},
  uprof(){const x=S.acc[S.pu];if(!x)return sheet('<h3>Pengguna tidak ditemukan</h3>'+closeRow);const me=x.u===S.cur,ps=S.posts.filter(p=>p.u===x.u).slice(0,5),fol=S.me.fol.includes(x.u);
    return sheet(`<div style="text-align:center"><div class="av" style="width:84px;height:84px;font-size:46px;margin:auto">${avh(x)}</div><h3 style="margin-top:8px">${vname(x)}</h3><p class="mu">@${esc(x.u)}${x.owner?' · owner':''}${x.bn?' · 🚫 dibekukan':''}</p>
      <p class="mu">${isOn(x.u)?'<span class="onl">● online</span>':'terakhir dilihat '+lastSeen(x.u)}</p><p>${esc(x.bio||'')}</p>${statsHTML(x)}</div>
      ${me?'':`<div class="row" style="justify-content:center;flex-wrap:wrap;margin:10px 0"><button class="btn ${fol?'':'pr'}" data-a="ikuti" data-i="${x.u}">${fol?'Mengikuti':'Ikuti'}</button><button class="btn ${x.sd?'':'pr'}" data-a="save" data-u="${x.u}">${x.fd?'🤝 Teman':x.sd?'✓ Tersimpan':'💾 Simpan'}</button><button class="btn" data-a="chatu" data-u="${x.u}">💬 Chat</button></div>
      <div class="row" style="justify-content:center"><button class="btn" data-a="blk" data-u="${x.u}">${x.bk?'Buka blokir':'🚫 Blokir'}</button><button class="btn" data-a="rep" data-u="${x.u}">🚩 Laporkan</button></div>`}
      ${S.me.owner&&!me?ownerBox(x):''}${ps.length?'<h3 style="margin-top:12px">Postingan</h3>'+ps.map(postHTML).join(''):''}`+closeRow)},
  flist(){const f=S.fl,x=S.acc[f.u];if(!x)return '';const list=f.t==='fol'?Object.values(S.acc).filter(y=>(y.fol||[]).includes(f.u)):(x.fol||[]).map(n=>S.acc[n]).filter(Boolean);
    return sheet(`<h3>${f.t==='fol'?'Pengikut':'Mengikuti'} @${esc(f.u)}</h3>${list.length?list.map(personRow).join(''):'<p class="mu">Belum ada.</p>'}`+closeRow)},
  notif(){const l=(S.me.nf||[]).slice().reverse();
    return sheet(`<h3>🔔 Notifikasi</h3>${l.length?l.map(n=>{const f=nama(n.from),t=n.type==='comment'?'berkomentar: '+n.text:n.type==='mention'?'menyebutmu di '+n.text:n.type==='gift'?'mengirim hadiah '+n.text:n.type==='room'||n.type==='report'?n.text:NOTIF[n.type]||n.text;
      return `<div class="row nf ${n.ts>(S.me.nr||0)?'new':''}" data-a="profil" data-u="${esc(n.from)}"><div class="av">${avh(f)}</div><div style="flex:1"><b>${esc(f.n)}</b> ${esc(t)}<div class="mu">${ago(n.ts)}</div></div></div>`}).join(''):'<p class="mu">Belum ada notifikasi.</p>'}`+closeRow)},
  cari(){return sheet(`<input id="qs" class="au" placeholder="Cari orang, grup, postingan, #tag..." value="${esc(S.qs||'')}" autocomplete="off"><div id="qr">${searchHTML(S.qs||'')}</div>`+closeRow)},
  board(){const b=S.bd,sec=(t,l,u)=>`<h3 style="margin:12px 0 4px">${t}</h3>${l&&l.length?l.map((r,i)=>{const x=S.acc[r.u];return x?`<div class="row" style="margin:6px 0" data-a="profil" data-u="${esc(r.u)}"><b style="width:24px">${i+1}</b><div class="av">${avh(x)}</div><div style="flex:1" class="nm">${vname(x)}</div><span>🪙 ${r.c}</span></div>`:''}).join(''):'<p class="mu">Belum ada data.</p>'}`;
    return sheet(`<h3>🏆 Peringkat</h3>${b?sec('🎁 Pemberi hadiah (7 hari)',b.givers)+sec('💝 Penerima hadiah (7 hari)',b.receivers)+sec('💰 Koin terbanyak',b.rich):'<p class="mu">Memuat...</p>'}`+closeRow)},
  shop(){const m=S.me;return sheet(`<h3>🛒 Toko Bingkai</h3><p class="mu">Koinmu: 🪙 ${m.coins}</p>${(S.shop||[]).map(it=>{const own=(m.items||[]).includes(it.id),on=m.fr===it.id;
      return `<div class="row" style="margin:10px 0"><div class="av">${avh({av:'🙂',fr:it.id})}</div><div style="flex:1"><b>${esc(it.n)}</b><div class="mu">${own?'Dimiliki':'🪙 '+it.c}</div></div>${own?(on?`<button class="btn" data-a="shopop" data-i="${it.id}" data-o="unequip">Lepas</button>`:`<button class="btn pr" data-a="shopop" data-i="${it.id}" data-o="equip">Pakai</button>`):`<button class="btn pr" data-a="shopop" data-i="${it.id}" data-o="buy">Beli</button>`}</div>`}).join('')}`+closeRow)},
  pw(){return sheet(`<h3>🔑 Ganti sandi</h3><input id="pwo" class="au" type="password" placeholder="Sandi lama" autocomplete="current-password"><input id="pwn" class="au" type="password" placeholder="Sandi baru (min. 6)" autocomplete="new-password"><div class="row" style="margin-top:12px"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="pwok">Simpan</button></div>`)},
  deln(){return sheet(`<h3>Hapus akun?</h3><p class="mu" style="margin:6px 0 10px">Akun, postingan, dan story-mu akan dihapus permanen. Masukkan sandi untuk memastikan.</p><input id="dpw" class="au" type="password" placeholder="Sandi" autocomplete="current-password"><div class="row" style="margin-top:12px"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="delok">Hapus akun</button></div>`)},
  report(){return sheet(`<h3>🚩 Laporkan @${esc(S.pu)}</h3><input id="rr" class="au" maxlength="200" placeholder="Alasan (spam, pelecehan, dll.)"><div class="row" style="margin-top:12px"><button class="btn" style="flex:1" data-a="mx">Batal</button><button class="btn pr" style="flex:1" data-a="repok">Kirim laporan</button></div>`)}};
{const _mh=modalHTML;modalHTML=function(){return S.md&&MODALS[S.md]?MODALS[S.md]():_mh()}}

// ---------- story: lanjut otomatis, hadiah ----------
function storyOrder(){const by={};S.stories.forEach(s=>(by[s.u]=by[s.u]||[]).push(s));return Object.keys(by).sort((a,b)=>a===S.cur?-1:b===S.cur?1:Math.max(...by[b].map(x=>x.t))-Math.max(...by[a].map(x=>x.t)))}
function storyNextUser(){if(!V)return;const ord=storyOrder(),i=ord.indexOf(V.u),nx=ord.slice(i+1).find(u=>S.stories.some(s=>s.u===u&&!(s.seen||[]).includes(S.cur)));
  if(!nx)return storyClose();clearTimeout(V.t);if(V.url)URL.revokeObjectURL(V.url);V=null;storyOpen(nx)}
const giftBar=()=>`<div class="sgp">${GIFTS.map((g,i)=>`<button data-a="sgv" data-i="${i}" ${S.me.coins<g[2]?'disabled':''}>${g[0]}<small>${g[2]}</small></button>`).join('')}</div>`;

// ---------- aksi ----------
document.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,i=b.dataset.i,u=b.dataset.u,done=()=>{S.md=null};
  switch(a){
    case 'profil':if(!S.acc[u])return;if(u===S.cur){S.md=null;S.open=null;S.tab='me';return render()}S.md='uprof';S.pu=u;return render();
    case 'flist':S.md='flist';S.fl={u,t:b.dataset.t};return render();
    case 'chatu':S.md=null;S.open=u;return render();
    case 'save':return void act('/api/save',{u});
    case 'blk':return void act('/api/block',{u}).then(()=>toast('Diperbarui'));
    case 'rep':S.md='report';S.pu=u;return render();
    case 'repok':{const r=$('#rr').value;S.md=null;render();return void api('/api/report','POST',{u:S.pu,reason:r}).then(()=>toast('Laporan terkirim')).catch(x=>toast(x.message))}
    case 'atur':return void act('/api/owner/atur',{u:S.pu,f:+$('#af').value,l:+$('#al').value}).then(()=>toast('Angka disimpan'));
    case 'ban':return void act('/api/owner/ban',{u});
    case 'rdone':return void act('/api/owner/report',{id:+i});
    case 'notif':S.md='notif';S.me.nr=Date.now();api('/api/nread','POST',{}).catch(()=>{});return render();
    case 'cari':S.md='cari';S.qs='';render();{const q=$('#qs');if(q)q.focus()}return;
    case 'tag':S.qs=b.dataset.t;S.md='cari';return render();
    case 'gercep':if(!S.me.owner)return;S.md='gercep';if(u&&S.acc[u])S.gu=u;return render();
    case 'gadd':{const el=$(b.dataset.t==='f'?'#gf':'#gl');if(el)el.value=b.dataset.set?0:Math.max(0,(+el.value||0)+(+b.dataset.n));return}
    case 'gapply':return void act('/api/owner/atur',{u:$('#gu').value,ft:+$('#gf').value,lt:+$('#gl').value}).then(()=>toast('⚡ Angka diterapkan'));
    case 'greset':return void act('/api/owner/atur',{u:$('#gu').value,reset:true}).then(()=>toast('♻️ Dikembalikan ke angka asli'));
    case 'rbuka':S.md=null;S.open=i;return render();
    case 'board':S.md='board';S.bd=null;render();return void api('/api/board').then(d=>{S.bd=d;render()}).catch(x=>toast(x.message));
    case 'shop':S.md='shop';return render();
    case 'shopop':return void act('/api/shop',{id:i,op:b.dataset.o});
    case 'daily':return void api('/api/daily','POST',{}).then(r=>{toast('🎁 Bonus +'+r.bonus+' koin (hari ke-'+r.streak+')');return pull(true)}).catch(x=>toast(x.message));
    case 'mm':if(e.target.closest('a,video,audio'))return;S.md='msg';S.mm={k:curKey(),id:+i};return render();
    case 'react':{const m=S.mm;S.md=null;return void act('/api/react',{k:m.k,id:m.id,e:b.dataset.e})}
    case 'rx':return void act('/api/react',{k:curKey(),id:+i,e:b.dataset.e});
    case 'mcopy':{const m=(S.chats[S.mm.k]||[]).find(x=>x.id===S.mm.id);S.md=null;render();try{navigator.clipboard.writeText(m.t);toast('Teks disalin')}catch(_){toast('Tidak bisa menyalin')}return}
    case 'mrep':{const k=S.mm.k,m=(S.chats[k]||[]).find(x=>x.id===S.mm.id);S.rp={k,id:m.id,f:m.f,t:(m.t||(m.vn?'🎤 Voice note':'🎁 Hadiah')).slice(0,60)};S.em=null;S.md=null;render();const c=$('#ci');if(c)c.focus();return}
    case 'medit':{const k=S.mm.k,m=(S.chats[k]||[]).find(x=>x.id===S.mm.id);S.em={k,id:m.id};S.rp=null;S.md=null;render();const c=$('#ci');if(c){c.value=m.t;c.focus()}return}
    case 'mdel':{const m=S.mm;S.md=null;return void act('/api/msg',{k:m.k,id:m.id},'DELETE')}
    case 'rpx':S.rp=null;return render();
    case 'emx':S.em=null;return render();
    case 'prx':return void act('/api/posts/'+i+'/react',{e:b.dataset.e});
    case 'preact':S.md='preact';S.pm=+i;return render();
    case 'preactgo':{const id=S.pm;S.md=null;return void act('/api/posts/'+id+'/react',{e:b.dataset.e})}
    case 'pgift':S.md='pgift';S.pm=+i;return render();
    case 'pgv':{const id=S.pm,g=GIFTS[i];if(S.me.coins<g[2])return toast('Koin tidak cukup');S.md=null;return void act('/api/gift',{post:id,i:+i}).then(()=>toast('Hadiah '+g[1]+' terkirim'))}
    case 'vote':return void act('/api/posts/'+i+'/vote',{i:+b.dataset.o});
    case 'pollt':{const bx=document.querySelector('.pollbox');if(bx)bx.style.display=bx.style.display==='none'?'block':'none';return}
    case 'pollplus':{const h=[...document.querySelectorAll('.poi')].find(x=>x.style.display==='none');if(h)h.style.display='';return}
    case 'posting':return void doPost();
    case 'rvis':return void act('/api/rooms/'+S.ri+'/op',{op:'vis'});
    case 'pw':S.md='pw';return render();
    case 'pwok':return void api('/api/password','PUT',{o:$('#pwo').value,n:$('#pwn').value}).then(()=>{S.md=null;render();toast('Sandi diganti')}).catch(x=>toast(x.message));
    case 'deln':S.md='deln';return render();
    case 'delok':return void api('/api/me','DELETE',{p:$('#dpw').value}).then(()=>{localLogout();toast('Akun dihapus')}).catch(x=>toast(x.message));
    case 'sgift':if(V){V.gp=!V.gp;storyShow()}return;
    case 'sgv':{if(!V)return;const s=V.list[V.i],g=GIFTS[i];if(S.me.coins<g[2])return toast('Koin tidak cukup');return void act('/api/gift',{story:s.id,i:+i}).then(()=>{if(V){V.gp=false;storyShow()}toast('Hadiah '+g[1]+' terkirim')})}
  }});
document.addEventListener('input',e=>{const t=e.target;
  if(t.id==='ci')typing(t.dataset.k);
  if(t.id==='qs'){S.qs=t.value;const r=$('#qr');if(r)r.innerHTML=searchHTML(S.qs)}});
document.addEventListener('change',e=>{if(e.target.id==='gu'){S.gu=e.target.value;const x=S.acc[S.gu];if(x){$('#gf').value=x.fl||0;$('#gl').value=x.lk||0;$('#gi').textContent=gInfo(x)}}
  if(e.target.id==='sv')S.svis=e.target.checked;if(e.target.id==='rt'){const v=$('#rv');if(v)v.value=e.target.value==='c'?'1':'0'}});
