// Lapisan jaringan XoltApp: komunikasi ke server, sinkronisasi data, upload, voice note.
const API=String(window.XOLT_API||'').replace(/\/$/,'');
const mu=u=>!u?'':/^(https?:|data:|blob:)/.test(u)?u:API+u;
let TOKEN='';try{TOKEN=localStorage.getItem('xolt_token')||''}catch(e){}
async function api(p,method,body){
  let r;try{r=await fetch(API+p,{method:method||(body?'POST':'GET'),headers:Object.assign({'Content-Type':'application/json'},TOKEN?{Authorization:'Bearer '+TOKEN}:{}),body:body!==undefined?JSON.stringify(body):undefined})}
  catch(e){throw new Error('Tidak bisa terhubung ke server. Cek alamat server di config.js')}
  let j={};try{j=await r.json()}catch(e){}
  if(r.status===401&&TOKEN){localLogout();throw new Error('Sesi berakhir, silakan masuk lagi')}
  if(!r.ok)throw new Error(j.error||('Kesalahan '+r.status));return j}
async function act(p,b,m){try{const r=await api(p,m||'POST',b||{});await pull(true);return r}catch(e){toast(e.message)}}
async function upload(x){
  const data=typeof x==='string'?x:await new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=()=>no(new Error('Gagal membaca file'));r.readAsDataURL(x)});
  return (await api('/api/upload','POST',{data})).url}
let pulling=false;
function liveUpd(d){S.skew=(d.now||Date.now())-Date.now();S.pr=d.pr||{};S.ty=d.ty||{};
  const sig=JSON.stringify(Object.keys(S.pr).filter(k=>isOn(k)).sort())+JSON.stringify(S.ty),ch=sig!==S.sig;S.sig=sig;return ch}
async function pull(force){
  if(pulling&&!force)return;pulling=true;let d;
  try{d=await api('/api/state?v='+(force?0:S.ver))}catch(e){pulling=false;if(!S.off&&TOKEN){S.off=true;toast('Server tidak terjangkau')}return}
  pulling=false;S.off=false;if(!d.same&&!d.me)return;
  const ch=liveUpd(d);
  if(d.same){if(ch&&S.me){S.keep=1;render()}return}
  S.ver=d.v;S.acc=d.users;S.cur=d.me;S.me=S.acc[d.me];
  S.posts=d.posts.map(p=>(p.w=ago(p.ts),p));S.stories=d.stories;S.rooms=d.rooms;S.reads=d.reads||{};S.shop=d.shop||[];S.rpt=d.reports||[];
  for(const k in d.chats)d.chats[k].forEach(m=>{m.w=new Date(m.ts).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'})});
  S.chats=Object.assign({global:[]},d.chats);S.keep=1;render()}
function localLogout(){
  TOKEN='';try{localStorage.removeItem('xolt_token')}catch(e){}
  if(typeof storyClose==='function')storyClose(true);vnStop(false);
  Object.assign(S,{cur:null,me:null,acc:{},posts:[],stories:[],rooms:[],chats:{global:[]},ver:0,open:null,gift:false,rec:false,tab:'feed',am:'login',md:null,ed:null,sp:null});render()}
// ---- jaga isi input & scroll saat data diperbarui otomatis ----
function snap(){const o={ids:{},sv:($('#v')||{}).scrollTop,fa:document.activeElement&&document.activeElement.id,ms:null};
  const ms=$('#ms');if(ms)o.ms={top:ms.scrollTop,end:ms.scrollHeight-ms.scrollTop-ms.clientHeight<80};
  document.querySelectorAll('#v input[id],#v textarea[id],#v select[id],#ovl input[id],#ovl textarea[id],#ovl select[id]').forEach(e=>{if(e.type==='file')return;o.ids[e.id]=e.type==='checkbox'?e.checked:e.value;if(e.id===o.fa){o.s=e.selectionStart;o.e=e.selectionEnd}});return o}
function unsnap(o){
  for(const id in o.ids){const e=document.getElementById(id);if(e){if(e.type==='checkbox')e.checked=o.ids[id];else e.value=o.ids[id]}}
  const v=$('#v');if(v&&o.sv&&S.tab!=='global')v.scrollTop=o.sv;
  const ms=$('#ms');if(ms&&o.ms&&!o.ms.end)ms.scrollTop=o.ms.top;
  if(o.fa){const e=document.getElementById(o.fa);if(e){e.focus();try{if(o.s!=null)e.setSelectionRange(o.s,o.e)}catch(_){}}}}
// ---- voice note ----
let REC=null;const VNA={a:null,u:'',p:false};
const fmtd=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
async function vnStart(){
  if(!navigator.mediaDevices||!window.MediaRecorder)return toast('Browser ini tidak mendukung perekaman suara');
  if(!window.isSecureContext)return toast('Voice note butuh alamat HTTPS. Buka XoltApp lewat https://');
  try{const st=await navigator.mediaDevices.getUserMedia({audio:true});
    const mt=['audio/webm;codecs=opus','audio/webm','audio/mp4','audio/ogg'].find(t=>MediaRecorder.isTypeSupported(t))||'';
    const mr=new MediaRecorder(st,mt?{mimeType:mt}:{}),ch=[];mr.ondataavailable=e=>{if(e.data&&e.data.size)ch.push(e.data)};
    REC={mr,st,ch,t0:Date.now(),key:S.open||'global',tm:setTimeout(()=>vnStop(true),120000)};mr.start();S.rec=true;render()}
  catch(e){toast(e&&e.name==='NotAllowedError'?'Izin mikrofon ditolak. Aktifkan di pengaturan browser':'Mikrofon tidak tersedia')}}
function vnStop(send){
  const r=REC;if(!r)return;REC=null;clearTimeout(r.tm);S.rec=false;
  r.mr.onstop=async()=>{r.st.getTracks().forEach(t=>t.stop());if(!send)return;
    const d=Math.max(1,Math.round((Date.now()-r.t0)/1000));if(!r.ch.length)return toast('Rekaman kosong');
    toast('Mengirim voice note...');try{const url=await upload(new Blob(r.ch,{type:r.mr.mimeType||'audio/webm'}));await act('/api/chat',{to:r.key,vn:{url,d}})}catch(e){toast(e.message)}};
  try{r.mr.stop()}catch(e){r.st.getTracks().forEach(t=>t.stop())}
  render()}
function vnPlay(u){
  if(VNA.u===u&&VNA.a&&!VNA.a.paused){VNA.a.pause();return}
  if(VNA.a){VNA.a.onended=VNA.a.onpause=null;VNA.a.pause()}
  const a=new Audio(mu(u));VNA.a=a;VNA.u=u;VNA.p=true;
  a.onended=a.onpause=()=>{VNA.p=false;render()};
  a.play().then(()=>render()).catch(()=>{VNA.p=false;toast('Tidak bisa memutar voice note');render()})}
// ---- mulai ----
async function boot(){if(TOKEN)await pull(true);render();loop()}
function loop(){setTimeout(async()=>{if(TOKEN&&S.me)await pull();loop()},document.hidden?8000:(S.open||S.tab==='global')?1800:3500)}
