# XoltApp Server

Satu server untuk semua HP: akun, postingan (foto/video/polling), story (publik/privat), chat global/pribadi/grup/channel (publik/privat), voice note, hadiah, notifikasi, pencarian, toko bingkai, peringkat, dan panel owner.
Data disimpan di folder `data/` (db.json + uploads). Tanpa `npm install`, cukup Node.js 18+.

## Jalankan
1. Salin `.env.example` menjadi `.env`, isi `OWNER_USERNAME` dan `OWNER_PASSWORD`.
2. `node server.js`  (atau `npm start`)
3. Buka `http://alamat-server:PORT` di HP. Aplikasi ikut disajikan dari server ini (folder `public/`).

Di panel Pterodactyl: unggah semua isi folder ini, set file awal `server.js`, isi variabel OWNER_USERNAME dan OWNER_PASSWORD, lalu Start. Port diambil otomatis dari SERVER_PORT/PORT.

## Penting: HTTPS
- **Voice note memakai mikrofon, dan browser hanya mengizinkannya di alamat HTTPS** (atau localhost). Lewat `http://` biasa tombol voice note menampilkan peringatan.
- Halaman di **Netlify (https) tidak boleh memanggil server `http://`** (diblokir browser). Server harus punya alamat `https://`.
- Cara termudah mendapat HTTPS: tunnel Cloudflare `cloudflared tunnel --url http://localhost:PORT` (gratis, menghasilkan alamat https), atau hosting yang menyediakan HTTPS otomatis (Render, Railway, Koyeb, VPS + Caddy/Nginx).
- Kalau aplikasi tetap di Netlify, isi `window.XOLT_API='https://alamat-server-kamu'` di `public/config.js` dan set `ALLOW_ORIGIN` ke alamat Netlify-mu. Kalau dibuka langsung dari server, biarkan kosong.

## Keamanan
- Sandi di-hash (scrypt), sandi owner hanya dari environment, tidak ada di kode.
- Pembatasan percobaan login, ukuran upload maksimal 25 MB, jenis file dibatasi gambar/video/audio.
- Cadangkan folder `data/` secara berkala. Ganti sandi owner dengan mengubah `.env` lalu restart.

## Fitur penting
- **Profil & pengikut:** Mengikuti / Pengikut / Suka di profil sendiri dan profil orang lain; ketuk angka untuk melihat daftarnya.
- **Simpan (kontak):** tombol Simpan di profil. Jika dua orang saling menyimpan mereka menjadi **Teman**; story privat hanya terlihat oleh Teman.
- **Grup/channel:** pilih Publik (siapa saja bisa gabung dari Jelajah) atau Privat (hanya yang diundang). Admin bisa mengubahnya di Info.
- **Owner:** panel Owner untuk pengumuman, centang biru, laporan, pembekuan akun, dan *penyesuaian angka pengikut/suka* (angka tampil = asli + penyesuaian; hanya owner yang bisa mengatur).
- **Blokir, laporan, ganti sandi, hapus akun, bonus harian, toko bingkai, peringkat hadiah.**
- Notifikasi push saat aplikasi tertutup dan panggilan suara/video belum ada (butuh Flutter / server WebRTC).
